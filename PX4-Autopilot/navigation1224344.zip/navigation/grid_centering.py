import cv2
import numpy as np
import math
print("### LOADED intersection_centering_v2 ###")
print(__file__)

class IntersectionCenteringV2:

    def __init__(self):

        # реальная ширина линии
        self.LINE_WIDTH_M = 0.10

        # максимальная дистанция между найденными узлами
        self.NODE_CLUSTER_RADIUS = 12

        # минимальное число соседей
        self.MIN_NODE_NEIGHBORS = 3

        self.debug = True

    # --------------------------------------------------------
    # Skeleton
    # --------------------------------------------------------

    def skeletonize(self, mask):

        if mask.dtype != np.uint8:
            mask = mask.astype(np.uint8)

        if mask.max() == 1:
            mask = mask * 255

        try:
            import cv2.ximgproc

            skeleton = cv2.ximgproc.thinning(mask)

        except Exception:

            from skimage.morphology import skeletonize

            skeleton = skeletonize(mask > 0)

            skeleton = skeleton.astype(np.uint8) * 255

        return skeleton

    # --------------------------------------------------------
    # Соседи
    # --------------------------------------------------------

    def neighbors(self, skeleton, x, y):

        h, w = skeleton.shape

        pts = []

        for dy in (-1, 0, 1):

            for dx in (-1, 0, 1):

                if dx == 0 and dy == 0:
                    continue

                xx = x + dx
                yy = y + dy

                if xx < 0 or yy < 0:
                    continue

                if xx >= w or yy >= h:
                    continue

                if skeleton[yy, xx] > 0:
                    pts.append((xx, yy))

        return pts

    # --------------------------------------------------------
    # Поиск всех узлов
    # --------------------------------------------------------

    def find_nodes(self, skeleton):

        h, w = skeleton.shape

        nodes = []

        for y in range(1, h - 1):

            for x in range(1, w - 1):

                if skeleton[y, x] == 0:
                    continue

                n = self.neighbors(skeleton, x, y)

                if len(n) >= 3:

                    nodes.append((x, y))

        return nodes

    def trace_branch(self,skel, start, prev):
        """
        Идем по ветке пока не пройдем ~20 пикселей.
        Возвращает конечную точку ветки.
        """

        y, x = start
        py, px = prev

        steps = 0

        while steps < 20:

            nxt = []

            for ny in (y - 1, y, y + 1):
                for nx in (x - 1, x, x + 1):

                    if ny == y and nx == x:
                        continue

                    if ny == py and nx == px:
                        continue

                    if ny < 0 or nx < 0:
                        continue

                    if ny >= skel.shape[0] or nx >= skel.shape[1]:
                        continue

                    if skel[ny, nx]:
                        nxt.append((ny, nx))
            print("steps =", steps, "next =", len(nxt))

            if len(nxt) == 0:
                break

            # если несколько вариантов — берем самый удаленный
            if len(nxt) > 1:
                nxt.sort(key=lambda p: (p[0] - py) ** 2 + (p[1] - px) ** 2, reverse=True)

            py, px = y, x
            y, x = nxt[0]

            steps += 1

        return x, y

    def classify_node(self,skel, node):
        """
        Возвращает:
            type
            center
            directions
        """

        x, y = node

        neighbors = []

        for ny in (y - 1, y, y + 1):
            for nx in (x - 1, x, x + 1):

                if ny == y and nx == x:
                    continue

                if ny < 0 or nx < 0:
                    continue

                if ny >= skel.shape[0]:
                    continue

                if nx >= skel.shape[1]:
                    continue

                if skel[ny, nx]:
                    neighbors.append((ny, nx))

        rays = []

        for n in neighbors:

            ex, ey = self.trace_branch(skel, n, node)

            dx = ex - x
            dy = ey - y

            length = math.sqrt(dx * dx + dy * dy)

            if length < 5:
                continue

            dx /= length
            dy /= length

            rays.append((dx, dy))

        if len(rays) >= 4:
            kind = "cross"

        elif len(rays) == 3:
            kind = "T"

        elif len(rays) == 2:

            dot = rays[0][0] * rays[1][0] + rays[0][1] * rays[1][1]

            angle = math.degrees(math.acos(max(-1, min(1, dot))))

            if angle > 150:
                kind = "line"

            else:
                kind = "corner"

        else:

            kind = "unknown"
        print("neighbors =", len(neighbors))
        print("rays =", len(rays))
        print(rays)
        print("kind =", kind)
        return kind, (x, y), rays

    def refine_center(self,mask, center):
        """
        Уточняет центр перекрестка по центру массы белых пикселей
        в небольшом окне.

        Это намного стабильнее, чем брать просто узел скелета.
        """
        print("input center =", center)

        cx, cy = center
        radius = 35

        h, w = mask.shape

        x1 = max(0, cx - radius)
        x2 = min(w, cx + radius)

        y1 = max(0, cy - radius)
        y2 = min(h, cy + radius)

        roi = mask[y1:y2, x1:x2]

        M = cv2.moments(roi)

        if M["m00"] == 0:
            return cx, cy

        mx = int(M["m10"] / M["m00"])
        my = int(M["m01"] / M["m00"])
        print("output center =", (x1 + mx, y1 + my))

        return x1 + mx, y1 + my

    def calculate_scale(self,mask, center, line_width_m=0.10):
        """
        Вычисляет масштаб (метров на пиксель)
        по реальной ширине линии.

        Возвращает:
            meters_per_pixel

        Если вычислить нельзя -> None
        """

        cx, cy = center
        print("center =", center)
        print("mask shape =", mask.shape)
        h, w = mask.shape

        widths = []

        #
        # измеряем ширину линии в нескольких строках
        #

        for yy in range(max(0, cy - 20), min(h, cy + 20)):

            window = 80

            row = mask[yy]

            x1 = max(0, cx - window)
            x2 = min(w, cx + window)

            left = cx
            while left > x1 and row[left] > 0:
                left -= 1

            right = cx
            while right < x2 - 1 and row[right] > 0:
                right += 1

            width = right - left - 1

            if width > 3:
                widths.append(width)

        #
        # удаляем мусор
        #

        widths = [w for w in widths if w > 3]
        print("widths =", widths)
        if len(widths) == 0:
            return None

        #
        # медиана намного устойчивее среднего
        #

        width_px = np.median(widths)

        return line_width_m / width_px

    def calculate_offset(self,center, frame_shape, meters_per_pixel):
        """
        Вычисляет смещение центра перекрестка относительно центра кадра.

        Возвращает:

            dx_m
            dy_m

        dx > 0  -> перекресток справа

        dx < 0  -> перекресток слева

        dy > 0  -> перекресток ниже

        dy < 0  -> перекресток выше
        """

        cx, cy = center

        frame_h, frame_w = frame_shape[:2]

        image_cx = frame_w * 0.5
        image_cy = frame_h * 0.5

        dx_px = cx - image_cx
        dy_px = cy - image_cy

        print("========== OFFSET DEBUG ==========")
        print(f"Center: ({cx}, {cy})")
        print(f"Image center: ({image_cx}, {image_cy})")
        print(f"dx_px = {dx_px}")
        print(f"dy_px = {dy_px}")
        print(f"meters_per_pixel = {meters_per_pixel}")

        dx_m = dx_px * meters_per_pixel
        dy_m = dy_px * meters_per_pixel

        return dx_m, dy_m

    def draw_debug(self,frame,
                   center,
                   dx,
                   dy,
                   kind,
                   rays=None):
        """
        Рисует всю отладочную информацию.

        frame     - исходный кадр
        center    - найденный центр перекрестка
        dx,dy     - смещение (метры)
        kind      - cross / T / corner
        rays      - список направлений веток (необязательно)
        """

        h, w = frame.shape[:2]

        cx_img = int(w / 2)
        cy_img = int(h / 2)

        cx = int(center[0])
        cy = int(center[1])

        #
        # центр изображения
        #

        cv2.drawMarker(
            frame,
            (cx_img, cy_img),
            (255, 0, 0),
            markerType=cv2.MARKER_CROSS,
            markerSize=30,
            thickness=3
        )

        #
        # найденный центр перекрестка
        #

        cv2.circle(
            frame,
            (cx, cy),
            8,
            (0, 0, 255),
            2
        )

        cv2.circle(
            frame,
            (cx, cy),
            2,
            (0, 0, 255),
            -1
        )

        #
        # соединяющий вектор
        #

        cv2.arrowedLine(frame,
                        (cx_img, cy_img),
                        (cx, cy),
                        (0, 255, 255),
                        2,
                        tipLength=0.1)

        if hasattr(self, "meters_per_pixel") and self.meters_per_pixel is not None:
            half_box_px = round(0.05 / self.meters_per_pixel)

            cv2.rectangle(
                frame,
                (cx - half_box_px, cy - half_box_px),
                (cx + half_box_px, cy + half_box_px),
                (0, 255, 0),
                2
            )

            cv2.circle(
                frame,
                (cx, cy),
                3,
                (0, 255, 0),
                -1
            )

            cv2.putText(
                frame,
                f"10 cm ({half_box_px * 2}px)",
                (cx + 15, cy + 20),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.5,
                (0, 255, 0),
                2
            )


        #
        # лучи (если есть)
        #

        if rays is not None:

            for rx, ry in rays:
                x2 = int(cx + rx * 60)
                y2 = int(cy + ry * 60)

                cv2.line(frame,
                         (cx, cy),
                         (x2, y2),
                         (0, 255, 0),
                         2)
                #
                # подписи
                #

                cv2.putText(
                    frame,
                    f"type : {kind}",
                    (20, 35),
                    cv2.FONT_HERSHEY_SIMPLEX,
                    0.8,
                    (0, 255, 255),
                    2
                )

                cv2.putText(
                    frame,
                    f"dx : {dx:+.3f} m",
                    (20, 70),
                    cv2.FONT_HERSHEY_SIMPLEX,
                    0.8,
                    (0, 255, 255),
                    2
                )

                cv2.putText(
                    frame,
                    f"dy : {dy:+.3f} m",
                    (20, 105),
                    cv2.FONT_HERSHEY_SIMPLEX,
                    0.8,
                    (0, 255, 255),
                    2
                )

        cv2.putText(
            frame,
            f"{self.meters_per_pixel * 1000:.2f} mm/px",
            (20, 140),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.7,
            (255, 255, 0),
            2
        )

        return frame
    # --------------------------------------------------------
    # Объединение близких узлов
    # --------------------------------------------------------
    def cluster_nodes(self, nodes):

        if len(nodes) == 0:
            return []

        visited = [False] * len(nodes)

        clusters = []

        for i in range(len(nodes)):

            if visited[i]:
                continue

            stack = [i]

            visited[i] = True

            cluster = []

            while stack:

                idx = stack.pop()

                cluster.append(nodes[idx])

                x1, y1 = nodes[idx]

                for j in range(len(nodes)):

                    if visited[j]:
                        continue

                    x2, y2 = nodes[j]

                    dist = np.hypot(x1 - x2, y1 - y2)

                    if dist < self.NODE_CLUSTER_RADIUS:

                        visited[j] = True

                        stack.append(j)

            clusters.append(cluster)

        return clusters

    # --------------------------------------------------------
    # Центр каждого кластера
    # --------------------------------------------------------

    def cluster_centers(self, clusters):

        centers = []

        for cluster in clusters:

            xs = [p[0] for p in cluster]

            ys = [p[1] for p in cluster]

            cx = int(np.median(xs))

            cy = int(np.median(ys))

            centers.append((cx, cy))

        return centers

    # --------------------------------------------------------
    # Debug
    # --------------------------------------------------------
    def draw_nodes(self, image, centers):

        h, w = image.shape[:2]

        frame_cx = w // 2
        frame_cy = h // 2

        # центр изображения
        cv2.drawMarker(
            image,
            (frame_cx, frame_cy),
            (255, 0, 0),
            markerType=cv2.MARKER_CROSS,
            markerSize=20,
            thickness=2
        )

        for x, y in centers:
            # центр перекрестка
            cv2.circle(
                image,
                (int(x), int(y)),
                5,
                (255, 0, 255),  # фиолетовый
                1
            )

            # линия до центра перекрестка
            cv2.arrowedLine(
                image,
                (frame_cx, frame_cy),
                (int(x), int(y)),
                (0, 255, 255),
                2,
                tipLength=0.08
            )

            # подпись координат
            cv2.putText(
                image,
                f"({int(x)}, {int(y)})",
                (int(x) + 12, int(y) - 12),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.5,
                (255, 255, 255),
                2
            )

    def update(self,mask,
               frame,
               line_width_m=0.10):
        """
        Главная функция.

        Возвращает

            found
            center_x
            center_y
            dx_m
            dy_m
            kind

        Если перекресток не найден

            False, None, None, 0, 0, "unknown"
        """

        #
        # 1. скелетизация
        #

        skel = self.skeletonize(mask)

        #
        # 2. поиск узлов
        #

        nodes = self.find_nodes(skel)

        if len(nodes) == 0:
            return False, None, None, 0.0, 0.0, "unknown"
        clusters = self.cluster_nodes(nodes)

        centers = self.cluster_centers(clusters)
        if self.debug:
            self.draw_nodes(frame, centers)
        if len(centers) == 0:
            return False, None, None, 0.0, 0.0, "unknown"
        #
        # 3. берем узел, ближайший к центру кадра
        #

        h, w = skel.shape

        image_cx = w / 2
        image_cy = h / 2
        best_center = None
        best_dist = 1e18

        for cx, cy in centers:

            d = (cx - image_cx) ** 2 + (cy - image_cy) ** 2

            if d < best_dist:
                best_dist = d
                best_center = (cx, cy)

        #
        # 4. классификация
        #

        kind, center0, rays = self.classify_node(
            skel,
            best_center
        )

        print("kind =", kind)

        if kind not in ("cross", "T", "corner"):
            print("FAIL: invalid kind")
            return False, None, None, 0.0, 0.0, "unknown"

        #
        # 5. уточняем центр
        #
        print("before refine =", center0)

        center = self.refine_center(mask, center0)

        print("after refine =", center)
        #
        # 6. масштаб
        #
        print("center =", center)
        print("mask value =", mask[center[1], center[0]])
        meters_per_pixel = self.calculate_scale(
            mask,
            center,
            line_width_m
        )

        if meters_per_pixel is None:
            print("FAIL: calculate_scale returned None")
            return False, None, None, 0.0, 0.0, "unknown"

        print("meters_per_pixel =", meters_per_pixel)
        print("10 cm =", 0.10 / meters_per_pixel, "px")

        self.meters_per_pixel = meters_per_pixel

        #
        # 7. вычисляем dx dy
        #

        dx, dy = self.calculate_offset(
            center,
            frame.shape,
            meters_per_pixel
        )

        #
        # 8. рисуем дебаг
        #

        self.draw_debug(
            frame,
            center,
            dx,
            dy,
            kind,
            rays
        )

        #
        # готово
        #

        return (
            True,
            center[0],
            center[1],
            dx,
            dy,
            kind
        )

GridCentering = IntersectionCenteringV2
