from camera import Camera
from centering import Centering
from aruco_detector import detect_aruco, compute_center_offset
from aruco_detector import compute_center_offset_m
from camera_line_scanning import process_frame
from grid_centering import GridCentering
from pattern_detector import PatternSmoother
from dijkstra import load_table_from_csv
from marker_csv_store import MarkerCsvStore, DEFAULT_CSV_PATH as MODE3_MARKER_CSV_PATH
from mode3_coord_overlay import write_current_waypoint
from line_table_io import load_aruco_target_area
from altitude_estimator import load_aruco_altitude_table, estimate_altitude_from_aruco

import csv
import math
import struct
import time
import numpy as np
import rclpy
from rclpy.node import Node

from pymavlink import mavutil

from std_msgs.msg import String
from std_msgs.msg import Bool
from std_msgs.msg import Float32

from rclpy.qos import QoSProfile
from rclpy.qos import ReliabilityPolicy
from rclpy.qos import HistoryPolicy
from rclpy.qos import DurabilityPolicy

from px4_msgs.msg import OffboardControlMode
from px4_msgs.msg import TrajectorySetpoint
from px4_msgs.msg import VehicleCommand
from px4_msgs.msg import VehicleStatus
from px4_msgs.msg import VehicleOdometry


def compute_z_step_from_area_error(error, target_area):
    if error is None or target_area is None or target_area <= 0:
        return 0.0
    ratio = abs(error) / target_area
    return float(np.clip(ratio * MODE1_Z_GAIN, 0.0, MODE1_Z_MAX_STEP))


def clamp_z_setpoint_to_safety(ground_z, z_setpoint, max_height_m):
    if ground_z is None:
        return z_setpoint
    min_allowed_z = ground_z - max_height_m
    return max(z_setpoint, min_allowed_z)


MODE1_AREA_TOLERANCE = 5000
MODE1_Z_GAIN = 0.05
MODE1_Z_MAX_STEP = 1
MODE1_BLIND_CLIMB_STEP = 0.01
MODE1_XY_MAX_STEP = 1
MODE1_BLIND_MAX_HEIGHT = 2.0

# 추가된 부분: 아루코 마커 인식 후, x/y 오차가 이 범위(5cm) 안이면
# "정렬됐다"고 봐주는 허용오차
MODE1_XY_ALIGN_TOLERANCE_M = 0.05
MODE10_HEIGHT_TOLERANCE = 0.1

MODE11_HEIGHT_TOLERANCE = 0.1

# 추가된 부분(핵심): 목표 도달 후에도 고도가 이 밴드를 벗어나면
# AUTO_TAKEOFF_HEIGHT(2.0m)로 재보정한다.
MODE1_HEIGHT_RECOVER_LOW = 2.0   # 이 아래로 내려가면 재보정 시작
MODE1_HEIGHT_RECOVER_HIGH = 2.0 # 이 위로 올라가면 재보정 시작 
MODE11_CLIMB_STEP = 0.065         # 한 틱(0.1s)당 상승량(m) - 0.5 m/s(초당 50cm)로 상향
MODE11_JUMP_WARN_THRESHOLD_M = 0.5

MODE11_XY_GAIN_LOCKED = 2
MODE11_XY_GAIN_RELEASED = 0.5

MODE12_BLIND_CLIMB_STEP = 0.01
MODE12_HEIGHT_TOLERANCE = 0.1
MODE1_HOLD_YAW_NED = float('nan')

MODE1_XY_P_TARGET = 8
MODE1_Z_P_TARGET = 2
MODE1_XY_VEL_I_TARGET = 0
MODE1_XY_VEL_D_TARGET = 1.5
MODE1_Z_VEL_I_TARGET = 0
MODE1_Z_VEL_D_TARGET = 1.5

AUTO_TAKEOFF_HEIGHT = 2.0

MODE2_FORWARD_DISTANCE_M = 5.5
MODE2_TILTMAX_AIR_TARGET = 20.0
MODE2_XY_P_TARGET = 1.0
MODE2_XY_VEL_I_TARGET = 0.0
MODE2_XY_VEL_D_TARGET = 0.0
MODE2_UNKNOWN_STREAK_REQUIRED = 20
MODE2_DETECTION_DELAY_SEC = 7

# 추가된 부분(핵심): mode2 새 상태머신(blind -> align_h -> approach_v -> hover)용 상수.
# - MODE2_PASS_STREAK_REQUIRED: 수평선이 이 틱 수만큼 연속으로 "안 보여야"
#   진짜로 "지나쳤다"고 판정한다(순간적인 검출 실패로 오판하지 않게).
#   기존 MODE2_UNKNOWN_STREAK_REQUIRED와 같은 값이라 그대로 재사용.
MODE2_PASS_STREAK_REQUIRED = MODE2_UNKNOWN_STREAK_REQUIRED

# 추가된 부분(핵심): approach_v -> hover 사이의 search_grid 단계 상수.
# 수직선이 처음 보이자마자 급정지하지 않고, 이 각도(deg)에서 시작해서
# MODE2_SEARCH_PITCH_STEP_DEG씩 매 틱 줄여가며(피치-) 서서히 감속한다.
# 그 사이에 실제 격자점(교차 패턴)을 찾으면 그 즉시, 못 찾아도 감속이
# 다 끝나면(0도 도달) 그 자리에서 hover로 확정한다.
MODE2_SEARCH_INITIAL_PITCH_DEG = 30.0
MODE2_SEARCH_PITCH_STEP_DEG = 5.0
# 감속 시작 시점(피치=30도)의 전방 목표 거리(m). 감속될수록 비례해서 줄어듦.
MODE2_SEARCH_LOOKAHEAD_M = 1.0

# hover 단계에서 grid/아루코로 미세보정하는 최대 틱 수(0.1s/tick 기준 3초)
MODE2_FINE_CORRECT_MAX_TICKS = 30

# 추가된 부분(핵심, 성능): hover 단계에서 grid_centering/아루코 계산을
# 매 틱이 아니라 이 틱 수마다 한 번만 돌린다(연산량 절감). 대신
# 계산을 건너뛴 틱에는 hold_x/y를 재계산하지 않고 직전 확정값을
# 그대로 유지한다 - 그래야 드론이 밀리지 않는다(자세한 이유는
# mode2_step의 hover 분기 주석 참고).
MODE2_GRID_COMPUTE_INTERVAL = 10

# 수정된 부분(핵심, 확인 필요): 카메라 이미지 오프셋(dx, dy)을 드론 NED
# 위치 setpoint(x=전후, y=좌우)로 변환할 때의 축 매핑/부호.
# vio_publisher.py에서 "이미지 세로축(dy)=드론 전후, 가로축(dx)=드론 좌우"로
# 확인된 축 매핑을 그대로 재사용하지만(같은 카메라니까), 부호는
# vio_publisher 내부의 별도 반전 로직과 무관하게 여기서 새로 검증해야 한다.
# 시뮬레이션으로 실제 이동 방향 보고 반대면 -1로 뒤집을 것.
MODE2_FORWARD_OFFSET_SIGN = 1.0   # dy(이미지 세로) -> x(전후) 부호
MODE2_LATERAL_OFFSET_SIGN = 1.0   # dx(이미지 가로) -> y(좌우) 부호

MODE3_PATH_RESULT_CSV = '/home/jiseungwoo/Desktop/com1/PX4-Autopilot/navigation/path_result.csv'
MODE3_WAYPOINT_CSV = '/home/jiseungwoo/Desktop/com1/PX4-Autopilot/navigation/way_point.csv'
MODE3_HOVER_TICKS = 30
MODE3_GRID_LOG_CSV = '/home/jiseungwoo/Desktop/com1/PX4-Autopilot/navigation/mode3_grid_log.csv'
MODE3_MARKER_CORRECTION_MAX_TICKS = 200


def wrap_pi(angle):
    while angle > math.pi:
        angle -= 2.0 * math.pi
    while angle < -math.pi:
        angle += 2.0 * math.pi
    return angle


class WaypointFollower(Node):
    def __init__(self):
        super().__init__('baylands_waypoint_follower_odom')

        self.target_aruco_area = load_aruco_target_area('line_table.csv')
        if self.target_aruco_area is not None:
            self.get_logger().info(f'목표 아루코 마커 면적(area_px): {self.target_aruco_area}')
        else:
            self.get_logger().warn(
                'line_table.csv에서 아루코 목표 면적을 찾지 못했습니다 '
                '(mode1 / mode3 마커 z보정이 동작하지 않습니다)')

        # 추가된 부분(핵심): mode1의 고도 판단 기준을 EKF2 fused pos[2]가
        # 아니라 아루코 마커 픽셀 면적(=카메라가 직접 보는 값)으로 바꾸기
        # 위한 테이블. camera_line_scanning.py에서 쓰는 것과 동일한
        # (alt, area) 테이블을 여기서도 그대로 로드해서 쓴다.
        self.aruco_altitude_table = load_aruco_altitude_table('line_table.csv')
        if not self.aruco_altitude_table:
            self.get_logger().warn(
                'line_table.csv에서 아루코 고도 테이블(aru 블록)을 못 찾음 - '
                'mode1이 픽셀 기반 고도를 못 쓰고 EKF2로 폴백합니다.')

        self.odom = None
        self.status = None
        self.counter = 0

        self._init_mavlink_param_link()
        self.ground_z = None

        self.active_mode = None
        self.arm_seq_counter = 0

        self.mode1_hold_x = None
        self.mode1_hold_y = None
        self.mode1_z_setpoint = None
        self.mode1_prev_height = None
        self.mode1_reached_target = False
        self.mode1_aruco_first_detected = False
        # 추가된 부분: 목표 도달 후 고도가 안전밴드(1.5~2.5m)를 벗어나면
        # 다시 목표 고도(2.0m)로 재보정하는 상태 플래그
        self.mode1_correcting = False
        # 추가된 부분: x/y 오차가 5cm 이내인지(정렬 여부) 상태 추적용
        self.mode1_xy_aligned = False

        self.mode10_hold_x = None
        self.mode10_hold_y = None
        self.mode10_z_setpoint = None

        self.mode11_hold_x = None
        self.mode11_hold_y = None
        self.mode11_z_setpoint = None
        self.mode11_prev_height = None
        self.mode11_reached_target = False

        self.mode12_hold_x = None
        self.mode12_hold_y = None
        self.mode12_z_setpoint = None
        self.mode12_hgt_ref_backup = None
        self.mode12_reached_target = False
        self.mode12_prev_height = None
        self.line_first_detected = False
        self.create_subscription(
            Bool, '/vision/line_first_detected',
            self._line_first_detected_callback, 10)

        self.mode2_start_x = None
        self.mode2_y_setpoint = None
        self.mode2_z_setpoint = None
        self.mode2_hold_x = None
        self.mode2_hold_y = None
        self.mode2_stopped = False
        self.mode2_armed = False
        self.mode2_unknown_streak = 0
        self.mode2_pattern_smoother = None
        self.mode2_traveled_m = 0.0
        # 수정된 부분: 카운트다운(틱 수) 대신 지금 명령 중인 피치 각도
        # 자체를 상태로 들고 있는다 (30도 -> 5도씩 감소 -> 0도)
        self.mode2_current_pitch_deg = 0.0
        self.mode2_start_time = None

        # 추가된 부분(핵심): mode2 상태머신(blind -> align_h -> approach_v -> hover)
        self.mode2_phase = 'blind'
        self.mode2_pass_streak = 0
        self.mode2_fine_correct_ticks = 0
        self.mode2_grid_centering = GridCentering()

        self.mode3_waypoints = None
        self.mode3_index = 0
        self.mode3_mission_complete = False
        self.mode3_hold_wp = None
        self.mode3_at_intersection = False
        self.mode3_hovering = False
        self.mode3_hover_timer = 0
        self.mode3_pattern_smoother = None
        self.mode3_marker_store = None
        self.mode3_grid_log_csv = None
        self.mode3_marker_z_setpoint = None
        self.mode3_marker_correction_start = 0

        qos_profile = QoSProfile(
            reliability=ReliabilityPolicy.BEST_EFFORT,
            durability=DurabilityPolicy.VOLATILE,
            history=HistoryPolicy.KEEP_LAST,
            depth=1
        )

        self.offboard_pub = self.create_publisher(
            OffboardControlMode, '/fmu/in/offboard_control_mode', 10)
        self.setpoint_pub = self.create_publisher(
            TrajectorySetpoint, '/fmu/in/trajectory_setpoint', 10)
        self.command_pub = self.create_publisher(
            VehicleCommand, '/fmu/in/vehicle_command', 10)
        self.mode11_xy_gain_pub = self.create_publisher(
            Float32, '/mode11/xy_gain', 10)
        self.mode1_xy_gain_pub = self.create_publisher(
            Float32, '/mode1/xy_gain', 10)

        self.create_subscription(
            VehicleOdometry, '/fmu/out/vehicle_odometry',
            self.odometry_callback, qos_profile)
        self.create_subscription(
            VehicleStatus, '/fmu/out/vehicle_status',
            self.vehicle_status_callback, qos_profile)
        self.create_subscription(
            String, '/mode_command',
            self.mode_command_callback, 10)

        self.cam = Camera()
        self.centering = Centering(self.cam)
        self.speed_set = False

        self.timer = self.create_timer(0.1, self.timer_callback)
        self.cam_timer = self.create_timer(0.1, self.centering_tick)
        self.speed_timer = self.create_timer(1.0, self.set_speed_limit)

    def _line_first_detected_callback(self, msg):
        self.line_first_detected = bool(msg.data)

    def mode_command_callback(self, msg):
        cmd = msg.data.strip().lower()

        if self.active_mode == 'mode1' and cmd != 'mode1' \
                and self._mpc_tiltmax_air_backup is not None:
            self.set_px4_param('MPC_TILTMAX_AIR', self._mpc_tiltmax_air_backup)
            self.get_logger().info(
                f'[param] mode1 이탈 - MPC_TILTMAX_AIR을 '
                f'{self._mpc_tiltmax_air_backup}(원래값)으로 복원')
            self._mpc_tiltmax_air_backup = None

        if self.active_mode == 'mode1' and cmd != 'mode1' \
                and self._mode1_xy_p_backup is not None \
                and not self._mode1_xy_p_released:
            self.set_px4_param('MPC_XY_P', self._mode1_xy_p_backup)
            self.get_logger().warn(
                f'[param] mode1 이탈 - 아루코 마커 미검출 상태로 벗어남. '
                f'MPC_XY_P을 {self._mode1_xy_p_backup}(원래값)으로 강제 복원')
            self._mode1_xy_p_backup = None
            self._mode1_xy_p_released = True

        # 수정된 부분: z게인은 이제 진입 시 안 잠그니까, "잠긴 채로 못
        # 벗어남" 안전망이 아니라 "마커 검출로 1.2로 바뀐 걸 원래값으로
        # 되돌리는" 목적으로 바뀜 - released 여부와 무관하게 백업이 있으면
        # 항상 복원한다 (검출 안 됐으면 애초에 안 바뀌었으니 복원해도
        # 그대로, 검출됐으면 1.2 -> 원래값으로 되돌아감).
        if self.active_mode == 'mode1' and cmd != 'mode1' \
                and self._mode1_z_p_backup is not None:
            self.set_px4_param('MPC_Z_P', self._mode1_z_p_backup)
            self.get_logger().info(
                f'[param] mode1 이탈 - MPC_Z_P을 '
                f'{self._mode1_z_p_backup}(원래값)으로 복원')
            self._mode1_z_p_backup = None
            self._mode1_z_p_released = False

        # 추가된 부분: xy 속도루프 I/D 게인도 z게인과 동일하게 이탈 시 복원
        if self.active_mode == 'mode1' and cmd != 'mode1' \
                and self._mode1_xy_vel_i_backup is not None:
            self.set_px4_param('MPC_XY_VEL_I_ACC', self._mode1_xy_vel_i_backup)
            self.get_logger().info(
                f'[param] mode1 이탈 - MPC_XY_VEL_I_ACC을 '
                f'{self._mode1_xy_vel_i_backup}(원래값)으로 복원')
            self._mode1_xy_vel_i_backup = None
            self._mode1_xy_vel_i_released = False

        if self.active_mode == 'mode1' and cmd != 'mode1' \
                and self._mode1_xy_vel_d_backup is not None:
            self.set_px4_param('MPC_XY_VEL_D_ACC', self._mode1_xy_vel_d_backup)
            self.get_logger().info(
                f'[param] mode1 이탈 - MPC_XY_VEL_D_ACC을 '
                f'{self._mode1_xy_vel_d_backup}(원래값)으로 복원')
            self._mode1_xy_vel_d_backup = None
            self._mode1_xy_vel_d_released = False

        # 추가된 부분: z 속도루프 I/D 게인도 동일하게 이탈 시 복원
        if self.active_mode == 'mode1' and cmd != 'mode1' \
                and self._mode1_z_vel_i_backup is not None:
            self.set_px4_param('MPC_Z_VEL_I_ACC', self._mode1_z_vel_i_backup)
            self.get_logger().info(
                f'[param] mode1 이탈 - MPC_Z_VEL_I_ACC을 '
                f'{self._mode1_z_vel_i_backup}(원래값)으로 복원')
            self._mode1_z_vel_i_backup = None
            self._mode1_z_vel_i_released = False

        if self.active_mode == 'mode1' and cmd != 'mode1' \
                and self._mode1_z_vel_d_backup is not None:
            self.set_px4_param('MPC_Z_VEL_D_ACC', self._mode1_z_vel_d_backup)
            self.get_logger().info(
                f'[param] mode1 이탈 - MPC_Z_VEL_D_ACC을 '
                f'{self._mode1_z_vel_d_backup}(원래값)으로 복원')
            self._mode1_z_vel_d_backup = None
            self._mode1_z_vel_d_released = False

        if self.active_mode == 'mode11' and cmd != 'mode11' \
                and self._mode11_tiltmax_air_backup is not None:
            self.set_px4_param('MPC_TILTMAX_AIR', self._mode11_tiltmax_air_backup)
            self.get_logger().info(
                f'[param] mode11 이탈 - MPC_TILTMAX_AIR을 '
                f'{self._mode11_tiltmax_air_backup}(원래값)으로 복원')
            self._mode11_tiltmax_air_backup = None

        if self.active_mode == 'mode11' and cmd != 'mode11' \
                and self._mode11_xy_p_backup is not None \
                and not self._mode11_xy_p_released:
            self.set_px4_param('MPC_XY_P', self._mode11_xy_p_backup)
            self.get_logger().warn(
                f'[param] mode11 이탈 - 라인 미인식 상태로 벗어남. '
                f'MPC_XY_P을 {self._mode11_xy_p_backup}(원래값)으로 강제 복원')
            self._mode11_xy_p_backup = None
            self._mode11_xy_p_released = True


        if self.active_mode == 'mode2' and cmd != 'mode2':
            if self._mode2_tiltmax_air_backup is not None:
                self.set_px4_param('MPC_TILTMAX_AIR', self._mode2_tiltmax_air_backup)
                self.get_logger().info(
                    f'[param] mode2 이탈 - MPC_TILTMAX_AIR을 '
                    f'{self._mode2_tiltmax_air_backup}으로 복원')
                self._mode2_tiltmax_air_backup = None
            if self._mode2_xy_p_backup is not None:
                self.set_px4_param('MPC_XY_P', self._mode2_xy_p_backup)
                self.get_logger().info(
                    f'[param] mode2 이탈 - MPC_XY_P을 {self._mode2_xy_p_backup}으로 복원')
                self._mode2_xy_p_backup = None
            if self._mode2_xy_vel_i_backup is not None:
                self.set_px4_param('MPC_XY_VEL_I_ACC', self._mode2_xy_vel_i_backup)
                self.get_logger().info(
                    f'[param] mode2 이탈 - MPC_XY_VEL_I_ACC을 {self._mode2_xy_vel_i_backup}으로 복원')
                self._mode2_xy_vel_i_backup = None
            if self._mode2_xy_vel_d_backup is not None:
                self.set_px4_param('MPC_XY_VEL_D_ACC', self._mode2_xy_vel_d_backup)
                self.get_logger().info(
                    f'[param] mode2 이탈 - MPC_XY_VEL_D_ACC을 {self._mode2_xy_vel_d_backup}으로 복원')
                self._mode2_xy_vel_d_backup = None

        if self.active_mode == 'mode12' and cmd != 'mode12' \
                and self.mode12_hgt_ref_backup is not None:
            self.set_px4_param('EKF2_HGT_REF', self.mode12_hgt_ref_backup)
            self.get_logger().info(
                f'[param] mode12 이탈 - EKF2_HGT_REF을 '
                f'{self.mode12_hgt_ref_backup}(원래값)으로 복원')
            self.mode12_hgt_ref_backup = None

        if cmd == 'mode1':
            self.active_mode = 'mode1'
            self.arm_seq_counter = 0
            self.mode1_hold_x = None
            self.mode1_hold_y = None
            self.mode1_z_setpoint = None
            self.mode1_prev_height = None
            self.mode1_reached_target = False
            self.mode1_aruco_first_detected = False
            self.mode1_xy_aligned = False
            self.mode1_correcting = False
            # 수정된 부분(핵심, 버그 수정): MPC_TILTMAX_AIR을 0으로 누르는
            # 로직을 제거했다. 실비행 확인 결과, 이게 "비전 오차로 인한
            # 엉뚱한 반응"만 막는 게 아니라 기체 자체의 자세 자율안정화
            # (프로펠러 미세 불균형/지면 이착륙 시 비대칭 등을 스스로
            # 보정하는 것)까지 통째로 막아버려서, 오히려 사소한 물리적
            # 비대칭에도 못 버티고 랜덤한 방향으로 드리프트하는 원인이
            # 됐다. MPC_XY_P=0만으로도 "위치 오차를 쫓아가는" 의도된
            # 잠금은 충분히 달성되므로, tilt 자체를 막을 필요는 없다.
            self._mode1_xy_p_released = False
            backed_up_xy_p = self.get_px4_param('MPC_XY_P')
            if backed_up_xy_p is not None:
                self._mode1_xy_p_backup = backed_up_xy_p
                # 수정된 부분(버그 수정): 여기 실제 값이 1.0으로 들어가고
                # 있었는데 로그는 "-> 0"이라고 찍혀서 불일치였다 (예전에
                # MPC_TILTMAX_AIR에서 찾았던 것과 같은 종류의 버그).
                # 실제로 0.0으로 넣어야 "아루코 검출 전까지 잠금"이 진짜로
                # 동작한다.
                self.set_px4_param('MPC_XY_P', 4.0)
                self.get_logger().info(
                    f'[param] mode1 진입 - MPC_XY_P: '
                    f'{backed_up_xy_p} -> 4 (아루코 마커 검출 전까지 xy 반응 억제)')
            else:
                self.get_logger().warn(
                    '[param] MPC_XY_P 현재값 읽기 실패 - '
                    'xy 게인 억제 스킵 (수동으로 param set 필요할 수 있음)')

            # 수정된 부분(핵심): z(고도) 게인 진입 시 잠금(0으로 누르는 것)은
            # 제거. 블라인드 상승 자체를 방해할 위험이 있어서 빼기로 함.
            # 대신 나중에 마커 검출 시 복원할 수 있도록 원래값만 백업해두고,
            # 진입 시엔 건드리지 않는다(정상 게인 그대로 유지 -> 블라인드
            # 상승 정상 동작).
            self._mode1_z_p_released = False
            backed_up_z_p = self.get_px4_param('MPC_Z_P')
            if backed_up_z_p is not None:
                self._mode1_z_p_backup = backed_up_z_p
                self.get_logger().info(
                    f'[param] mode1 진입 - MPC_Z_P 원래값({backed_up_z_p}) 백업만 '
                    f'해둠 (잠그지 않음, 아루코 검출 시 {MODE1_Z_P_TARGET}로 변경 예정)')
            else:
                self.get_logger().warn(
                    '[param] MPC_Z_P 현재값 읽기 실패 - 백업 스킵')

            # 추가된 부분: xy 속도루프 I/D 게인도 백업만 (잠그지 않음)
            self._mode1_xy_vel_i_released = False
            backed_up_vel_i = self.get_px4_param('MPC_XY_VEL_I_ACC')
            if backed_up_vel_i is not None:
                self._mode1_xy_vel_i_backup = backed_up_vel_i
                self.get_logger().info(
                    f'[param] mode1 진입 - MPC_XY_VEL_I_ACC 원래값'
                    f'({backed_up_vel_i}) 백업만 해둠 (아루코 검출 시 '
                    f'{MODE1_XY_VEL_I_TARGET}로 변경 예정)')
            else:
                self.get_logger().warn(
                    '[param] MPC_XY_VEL_I_ACC 현재값 읽기 실패 - 백업 스킵')

            self._mode1_xy_vel_d_released = False
            backed_up_vel_d = self.get_px4_param('MPC_XY_VEL_D_ACC')
            if backed_up_vel_d is not None:
                self._mode1_xy_vel_d_backup = backed_up_vel_d
                self.get_logger().info(
                    f'[param] mode1 진입 - MPC_XY_VEL_D_ACC 원래값'
                    f'({backed_up_vel_d}) 백업만 해둠 (아루코 검출 시 '
                    f'{MODE1_XY_VEL_D_TARGET}로 변경 예정)')
            else:
                self.get_logger().warn(
                    '[param] MPC_XY_VEL_D_ACC 현재값 읽기 실패 - 백업 스킵')

            # 추가된 부분: z 속도루프 I/D 게인도 xy vel과 동일하게 백업만
            self._mode1_z_vel_i_released = False
            backed_up_z_vel_i = self.get_px4_param('MPC_Z_VEL_I_ACC')
            if backed_up_z_vel_i is not None:
                self._mode1_z_vel_i_backup = backed_up_z_vel_i
                self.get_logger().info(
                    f'[param] mode1 진입 - MPC_Z_VEL_I_ACC 원래값'
                    f'({backed_up_z_vel_i}) 백업만 해둠 (아루코 검출 시 '
                    f'{MODE1_Z_VEL_I_TARGET}로 변경 예정)')
            else:
                self.get_logger().warn(
                    '[param] MPC_Z_VEL_I_ACC 현재값 읽기 실패 - 백업 스킵')

            self._mode1_z_vel_d_released = False
            backed_up_z_vel_d = self.get_px4_param('MPC_Z_VEL_D_ACC')
            if backed_up_z_vel_d is not None:
                self._mode1_z_vel_d_backup = backed_up_z_vel_d
                self.get_logger().info(
                    f'[param] mode1 진입 - MPC_Z_VEL_D_ACC 원래값'
                    f'({backed_up_z_vel_d}) 백업만 해둠 (아루코 검출 시 '
                    f'{MODE1_Z_VEL_D_TARGET}로 변경 예정)')
            else:
                self.get_logger().warn(
                    '[param] MPC_Z_VEL_D_ACC 현재값 읽기 실패 - 백업 스킵')

            # 수정된 부분: 마그네토미터는 이제 코드에서 껐다 켰다 하지
            # 않는다. 애초에 안 쓸 거라 PX4 콘솔(pxh>)에서
            # `param set EKF2_MAG_TYPE 5` + `param save`로 영구 적용한다.

            self.get_logger().info(
                f'mode1 활성화 (mode11과 동일한 로직 - 블라인드로 '
                f'{AUTO_TAKEOFF_HEIGHT}m까지 상승 후 계속 호버링, '
                f'line-scanning VIO 추정치 안정성 관찰용)')
        elif cmd == 'mode2':
            self.active_mode = 'mode2'
            self.arm_seq_counter = 0
            self.mode2_start_x = None
            self.mode2_y_setpoint = None
            self.mode2_z_setpoint = None
            self.mode2_hold_x = None
            self.mode2_hold_y = None
            self.mode2_stopped = False
            self.mode2_armed = False
            self.mode2_unknown_streak = 0
            self.mode2_pattern_smoother = PatternSmoother(history_size=7)
            self.mode2_traveled_m = 0.0
            self.mode2_start_time = time.monotonic()
            self.mode2_phase = 'blind'
            self.mode2_pass_streak = 0
            self.mode2_fine_correct_ticks = 0
            self.mode2_current_pitch_deg = 0.0

            # 수정된 부분(핵심, 버그 수정): 백업 읽기가 실패(None)했는데도
            # 무조건 set_px4_param으로 값을 바꿔버리고 있었다. 그러면
            # 이탈 시 복원 로직(`if backup is not None:`)이 "바뀐 적
            # 없다"고 착각해서 절대 복원을 안 해준다 - 파라미터가 mode2
            # 값에 영구히 갇히는 사고로 이어질 수 있었다. mode1과 동일하게
            # 백업이 성공했을 때만 값을 바꾸도록 방어한다.
            self._mode2_tiltmax_air_backup = self.get_px4_param('MPC_TILTMAX_AIR')
            if self._mode2_tiltmax_air_backup is not None:
                self.set_px4_param('MPC_TILTMAX_AIR', MODE2_TILTMAX_AIR_TARGET)
            else:
                self.get_logger().warn(
                    '[param] MPC_TILTMAX_AIR 현재값 읽기 실패 - '
                    'mode2 tilt 제한 적용 스킵')

            self._mode2_xy_p_backup = self.get_px4_param('MPC_XY_P')
            if self._mode2_xy_p_backup is not None:
                self.set_px4_param('MPC_XY_P', MODE2_XY_P_TARGET)
            else:
                self.get_logger().warn(
                    '[param] MPC_XY_P 현재값 읽기 실패 - mode2 게인 적용 스킵')

            self._mode2_xy_vel_i_backup = self.get_px4_param('MPC_XY_VEL_I_ACC')
            if self._mode2_xy_vel_i_backup is not None:
                self.set_px4_param('MPC_XY_VEL_I_ACC', MODE2_XY_VEL_I_TARGET)
            else:
                self.get_logger().warn(
                    '[param] MPC_XY_VEL_I_ACC 현재값 읽기 실패 - mode2 게인 적용 스킵')

            self._mode2_xy_vel_d_backup = self.get_px4_param('MPC_XY_VEL_D_ACC')
            if self._mode2_xy_vel_d_backup is not None:
                self.set_px4_param('MPC_XY_VEL_D_ACC', MODE2_XY_VEL_D_TARGET)
            else:
                self.get_logger().warn(
                    '[param] MPC_XY_VEL_D_ACC 현재값 읽기 실패 - mode2 게인 적용 스킵')

            self.get_logger().info(
                f'mode2 활성화 (blind 전진(+x, 최대 {MODE2_FORWARD_DISTANCE_M:.2f}m 방향) '
                f'-> 수평선 감지 시 좌우 정렬(align_h) -> 수평선 지나침 감지 후 '
                f'수직선 감지 시 정지(approach_v) -> grid+아루코 미세보정(hover), '
                f'tilt 제한={MODE2_TILTMAX_AIR_TARGET:.1f}도, '
                f'P={MODE2_XY_P_TARGET}, I={MODE2_XY_VEL_I_TARGET}, '
                f'D={MODE2_XY_VEL_D_TARGET})')
        elif cmd == 'mode3':
            self._activate_mode3()
        elif cmd == 'mode10':
            self.active_mode = 'mode10'
            self.arm_seq_counter = 0
            self.mode10_hold_x = None
            self.mode10_hold_y = None
            self.mode10_z_setpoint = None
            self.get_logger().info(
                f'mode10 활성화 (아루코 없이 블라인드 {AUTO_TAKEOFF_HEIGHT}m '
                f'상승 후 mode3 자동 전환)')
        elif cmd == 'mode11':
            self.active_mode = 'mode11'
            self.arm_seq_counter = 0
            self.mode11_hold_x = None
            self.mode11_hold_y = None
            self.mode11_z_setpoint = None
            self.mode11_prev_height = None
            self.mode11_reached_target = False
            # 수정된 부분(핵심, 버그 수정): mode1과 동일한 이유로
            # MPC_TILTMAX_AIR을 0으로 누르는 로직 제거. MPC_XY_P=0만으로
            # 충분히 잠기고, tilt 자체를 막으면 오히려 자세 자율안정화가
            # 안 돼서 드리프트를 유발한다.
            self._mode11_xy_p_released = False
            backed_up_xy_p = self.get_px4_param('MPC_XY_P')
            if backed_up_xy_p is not None:
                self._mode11_xy_p_backup = backed_up_xy_p
                self.set_px4_param('MPC_XY_P', 0.0)
                self.get_logger().info(
                    f'[param] mode11 진입 - MPC_XY_P: '
                    f'{backed_up_xy_p} -> 0 (라인 인식 전까지 xy 반응 억제)')
            else:
                self.get_logger().warn(
                    '[param] MPC_XY_P 현재값 읽기 실패 - '
                    'xy 게인 억제 스킵 (수동으로 param set 필요할 수 있음)')

            self.get_logger().info(
                f'mode11 활성화 (순수 이륙 검증 전용 - '
                f'{AUTO_TAKEOFF_HEIGHT}m까지 상승 후 계속 호버링, '
                f'실제 line-scanning VIO 추정치 안정성 관찰용)')
        elif cmd == 'mode12':
            self.active_mode = 'mode12'
            self.arm_seq_counter = 0
            self.mode12_hold_x = None
            self.mode12_hold_y = None
            self.mode12_z_setpoint = None
            self.mode12_reached_target = False
            self.mode12_prev_height = None
            backed_up = self.get_px4_param('EKF2_HGT_REF')
            if backed_up is not None:
                self.mode12_hgt_ref_backup = backed_up
                self.set_px4_param('EKF2_HGT_REF', 0.0)
                self.get_logger().info(
                    f'[param] mode12 진입 - EKF2_HGT_REF: {backed_up} -> 0(Baro) '
                    f'(vision 완전 배제, 계속 유지)')
            else:
                self.get_logger().warn(
                    '[param] EKF2_HGT_REF 현재값 읽기 실패 - '
                    'baro 고도기준 자동전환 스킵')
            self.get_logger().info(
                f'mode12 활성화 (순수 EKF2/baro 기준 블라인드 상승 - '
                f'{AUTO_TAKEOFF_HEIGHT}m까지, vision 절대 미사용, x/y/yaw 고정)')
        else:
            self.get_logger().warn(
                f'알 수 없는 명령어: {cmd} (mode1 / mode2 / mode3 / mode10 / mode11 만 가능)')

    def _activate_mode3(self):
        self.active_mode = 'mode3'
        self.arm_seq_counter = 0
        if self.mode3_waypoints is None:
            try:
                self.mode3_waypoints = self.build_mode3_waypoints(
                    MODE3_PATH_RESULT_CSV, MODE3_WAYPOINT_CSV)
            except Exception as e:
                self.get_logger().error(f'[mode3] 경로 로드 실패: {e}')
                self.active_mode = None
                return
        self.mode3_index = 0
        self.mode3_mission_complete = False
        self.mode3_hold_wp = None
        self.mode3_at_intersection = False
        self.mode3_hovering = False
        self.mode3_hover_timer = 0
        self.mode3_pattern_smoother = PatternSmoother(history_size=7)
        self.mode3_marker_store = MarkerCsvStore(MODE3_MARKER_CSV_PATH)
        self.mode3_marker_store.reset()
        self._mode3_init_grid_log(MODE3_GRID_LOG_CSV)
        self.get_logger().info('mode3 활성화 (다익스트라 격자점 경로 미션, 현재 고도에서 바로 시작)')
        self.get_logger().info(f'[mode3] 마커 좌표 저장 CSV: {MODE3_MARKER_CSV_PATH}')
        self.get_logger().info(f'[mode3] 격자점 방문 로그 CSV: {MODE3_GRID_LOG_CSV}')

    def centering_tick(self):
        if self.active_mode in ('mode3', 'mode11'):
            self.centering.update()

    def set_speed_limit(self):
        if self.speed_set:
            return
        self.publish_vehicle_command(
            VehicleCommand.VEHICLE_CMD_DO_CHANGE_SPEED,
            param1=1.0, param2=2.0, param3=-1.0)
        self.speed_set = True
        self.get_logger().info('Speed limit set to 2.0 m/s')

    def odometry_callback(self, msg):
        self.odom = msg

    def vehicle_status_callback(self, msg):
        self.status = msg

    def px4_timestamp_us(self):
        return int(self.get_clock().now().nanoseconds / 1000)

    def publish_offboard_control_mode(self):
        msg = OffboardControlMode()
        msg.timestamp = self.px4_timestamp_us()
        msg.position = True
        msg.velocity = False
        msg.acceleration = False
        msg.attitude = False
        msg.body_rate = False
        self.offboard_pub.publish(msg)

    def publish_setpoint(self, wp):
        msg = TrajectorySetpoint()
        msg.timestamp = self.px4_timestamp_us()
        msg.position = [float(wp[0]), float(wp[1]), float(wp[2])]
        msg.yaw = float(wp[3])
        self.setpoint_pub.publish(msg)

    def publish_mode2_velocity_setpoint(self, velocity_x):
        msg = TrajectorySetpoint()
        msg.timestamp = self.px4_timestamp_us()
        msg.position = [float('nan'), float('nan'), float(self.mode2_z_setpoint)]
        msg.velocity = [float(velocity_x), 0.0, float('nan')]
        msg.acceleration = [float('nan'), float('nan'), float('nan')]
        msg.yaw = float('nan')
        self.setpoint_pub.publish(msg)

    def publish_vehicle_command(self, command, param1=0.0, param2=0.0,
                                param3=0.0, param4=0.0, param5=0.0,
                                param6=0.0, param7=0.0):
        msg = VehicleCommand()
        msg.timestamp = self.px4_timestamp_us()
        msg.param1 = float(param1)
        msg.param2 = float(param2)
        msg.param3 = float(param3)
        msg.param4 = float(param4)
        msg.param5 = float(param5)
        msg.param6 = float(param6)
        msg.param7 = float(param7)
        msg.command = command
        msg.target_system = 1
        msg.target_component = 1
        msg.source_system = 1
        msg.source_component = 1
        msg.from_external = True
        self.command_pub.publish(msg)

    def arm(self):
        self.publish_vehicle_command(
            VehicleCommand.VEHICLE_CMD_COMPONENT_ARM_DISARM, 1.0)

    def set_offboard_mode(self):
        self.publish_vehicle_command(
            VehicleCommand.VEHICLE_CMD_DO_SET_MODE, 1.0, 6.0)

    def is_armed(self):
        if self.status is None:
            return False
        return self.status.arming_state == VehicleStatus.ARMING_STATE_ARMED

    def is_offboard(self):
        if self.status is None:
            return False
        return self.status.nav_state == VehicleStatus.NAVIGATION_STATE_OFFBOARD

    def get_position_from_odometry(self):
        if self.odom is None:
            return None
        return (float(self.odom.position[0]),
                float(self.odom.position[1]),
                float(self.odom.position[2]))

    def ensure_armed_and_offboard(self, hold_wp):
        self.publish_setpoint(hold_wp)
        self.arm_seq_counter += 1

        if self.arm_seq_counter < 10:
            return False

        if not self.is_offboard():
            if self.arm_seq_counter % 10 == 0:
                self.set_offboard_mode()
                self.get_logger().info('Requesting OFFBOARD mode...')
            return False

        if not self.is_armed():
            if self.arm_seq_counter % 10 == 0:
                self.arm()
                self.get_logger().info('Requesting ARM...')
            return False

        return True

    def _init_mavlink_param_link(self):
        self._mav_param_link = None
        self._mpc_tiltmax_air_backup = None
        self._mode11_tiltmax_air_backup = None
        self._mode11_xy_p_backup = None
        self._mode11_xy_p_released = False
        self._mode1_xy_p_backup = None
        self._mode1_xy_p_released = False
        # 추가된 부분: z(고도) 게인도 xy와 동일한 잠금/해제 구조
        self._mode1_z_p_backup = None
        self._mode1_z_p_released = False
        # 추가된 부분: xy 속도루프 I/D 게인 백업 (z게인과 동일하게 잠금 없음)
        self._mode1_xy_vel_i_backup = None
        self._mode1_xy_vel_i_released = False
        self._mode1_xy_vel_d_backup = None
        self._mode1_xy_vel_d_released = False
        # 추가된 부분: z 속도루프 I/D 게인 백업 (xy vel과 동일하게 잠금 없음)
        self._mode1_z_vel_i_backup = None
        self._mode1_z_vel_i_released = False
        self._mode1_z_vel_d_backup = None
        self._mode1_z_vel_d_released = False
        self._mode2_tiltmax_air_backup = None
        self._mode2_xy_p_backup = None
        self._mode2_xy_vel_i_backup = None
        self._mode2_xy_vel_d_backup = None
        # 추가된 부분: 마그네토미터 융합을 mode1/mode11 진입 시 끄기 위한
        # 백업 변수. 실비행 확인 결과, EKF2가 마그네토미터 기반 요(yaw)를
        # 신뢰하면서 오히려 자세가 흔들려 랜덤 드리프트로 이어지는 것으로
        # 보여서 추가함.
        # 수정된 부분: 마그네토미터는 PX4 콘솔에서 영구적으로 끄기로 해서,
        # 코드에서 켰다 껐다 할 백업 변수가 더 이상 필요 없다.
        try:
            self._mav_param_link = mavutil.mavlink_connection(
                'udpin:0.0.0.0:14540', source_system=250)
            self.get_logger().info(
                'MAVLink param 링크 연결 시도 (mode1 tilt 자동 전환용, '
                'udpin:0.0.0.0:14540 바인드) - 첫 heartbeat 대기 중...')
            hb = self._mav_param_link.wait_heartbeat(timeout=5)
            if hb is not None:
                self.get_logger().info(
                    f'MAVLink heartbeat 수신 완료 '
                    f'(system={self._mav_param_link.target_system}, '
                    f'component={self._mav_param_link.target_component})')
            else:
                self.get_logger().warn(
                    'MAVLink heartbeat 5초 내 미수신 - PX4가 아직 안 떴거나 '
                    '포트가 안 맞을 수 있음 (tilt 자동 전환 불안정할 수 있음)')
        except Exception as e:
            self.get_logger().warn(
                f'MAVLink param 링크 연결 실패 (tilt 자동 전환 비활성화): {e}')

    def set_px4_param(self, name: str, value, param_type=None):
        if self._mav_param_link is None:
            return False
        if param_type is None:
            param_type = mavutil.mavlink.MAV_PARAM_TYPE_REAL32

        int_types = (
            mavutil.mavlink.MAV_PARAM_TYPE_UINT8,
            mavutil.mavlink.MAV_PARAM_TYPE_INT8,
            mavutil.mavlink.MAV_PARAM_TYPE_UINT16,
            mavutil.mavlink.MAV_PARAM_TYPE_INT16,
            mavutil.mavlink.MAV_PARAM_TYPE_UINT32,
            mavutil.mavlink.MAV_PARAM_TYPE_INT32,
        )
        try:
            if param_type in int_types:
                param_value = struct.unpack('<f', struct.pack('<i', int(value)))[0]
            else:
                param_value = float(value)

            self._mav_param_link.mav.param_set_send(
                self._mav_param_link.target_system,
                self._mav_param_link.target_component,
                name.encode('utf-8'),
                param_value,
                param_type,
            )
            self.get_logger().info(f'[param] {name} -> {value} 전송')
            return True
        except Exception as e:
            self.get_logger().warn(f'[param] {name} 설정 실패: {e}')
            return False

    def get_px4_param(self, name: str, timeout_sec: float = 3.0):
        if self._mav_param_link is None:
            return None

        int_types = (
            mavutil.mavlink.MAV_PARAM_TYPE_UINT8,
            mavutil.mavlink.MAV_PARAM_TYPE_INT8,
            mavutil.mavlink.MAV_PARAM_TYPE_UINT16,
            mavutil.mavlink.MAV_PARAM_TYPE_INT16,
            mavutil.mavlink.MAV_PARAM_TYPE_UINT32,
            mavutil.mavlink.MAV_PARAM_TYPE_INT32,
        )
        try:
            deadline = time.time() + timeout_sec
            resend_interval = 0.5
            next_send_time = 0.0  # 0으로 두면 아래 while 첫 루프에서 바로 전송됨

            while True:
                now = time.time()
                remaining = deadline - now
                if remaining <= 0:
                    self.get_logger().warn(
                        f'[param] {name} 읽기 타임아웃 - {timeout_sec}초 안에 '
                        f'일치하는 응답을 못 받음 (요청 패킷 유실 가능성 포함)')
                    break

                if now >= next_send_time:
                    self._mav_param_link.mav.param_request_read_send(
                        self._mav_param_link.target_system,
                        self._mav_param_link.target_component,
                        name.encode('utf-8'), -1)
                    next_send_time = now + resend_interval

                wait_time = min(resend_interval, remaining)
                msg = self._mav_param_link.recv_match(
                    type='PARAM_VALUE', blocking=True, timeout=wait_time)
                if msg is None:
                    continue  # 이번 대기 구간엔 아무 응답도 없었음 - 재전송하며 계속 대기
                if msg.param_id.strip('\x00') == name:
                    if msg.param_type in int_types:
                        return struct.unpack(
                            '<i', struct.pack('<f', msg.param_value))[0]
                    return msg.param_value
                # 이름이 다른 PARAM_VALUE면 무시하고 계속 기다린다
        except Exception as e:
            self.get_logger().warn(f'[param] {name} 읽기 실패: {e}')
        return None

    def mode1_step(self):
        pos = self.get_position_from_odometry()
        if pos is None:
            return

        if self.ground_z is None:
            self.ground_z = pos[2]
            self.get_logger().info(f'[mode1] 지면 NED z 기록: {self.ground_z:.3f}m')

        rclpy.spin_once(self.cam, timeout_sec=0.0)
        frame = self.cam.read()

        aruco_detected_now = False
        xy_error_m = None
        pixel_height = None
        if frame is not None:
            ids, area, corners = detect_aruco(frame)
            if ids is not None and area > 0 and len(corners) > 0:
                aruco_detected_now = True
                # 추가된 부분(핵심): 마커 인식 후 x/y 오차를 실제로 계산해서
                # 5cm 이내인지("정렬됐다") 판정한다. compute_center_offset_m은
                # 마커 실제 크기(0.4m) 기준으로 화면 중심 <-> 마커 중심의
                # 실제 물리 거리(m)를 준다.
                offset_info = compute_center_offset_m(frame.shape, corners[0])
                xy_error_m = offset_info['total_offset_m']
                self.mode1_xy_aligned = (
                    abs(offset_info['x_offset_m']) <= MODE1_XY_ALIGN_TOLERANCE_M
                    and abs(offset_info['y_offset_m']) <= MODE1_XY_ALIGN_TOLERANCE_M
                )
                # 추가된 부분(핵심): 재보정 구간에서만 쓸 픽셀 기반 고도를
                # 계산해둔다. estimate_altitude_from_aruco는 라인 테이블과
                # 동일한 규약 - 유효 범위 밖이면 -1.0을 반환하므로 > 0
                # 체크로 걸러낸다.
                if self.aruco_altitude_table:
                    est = estimate_altitude_from_aruco(area, self.aruco_altitude_table)
                    if est is not None and est > 0:
                        pixel_height = est

        if self.mode1_hold_x is None:
            self.mode1_hold_x = pos[0]
            self.mode1_hold_y = pos[1]
            self.mode1_z_setpoint = pos[2]

        hold_wp = [self.mode1_hold_x, self.mode1_hold_y,
                   self.mode1_z_setpoint, MODE1_HOLD_YAW_NED]

        if not self.ensure_armed_and_offboard(hold_wp):
            return

        # 수정된 부분(핵심, 버그 수정): 고도 판단을 EKF2 fused pos[2]
        # 하나로 통일한다. 이전엔 마커가 보이면 아루코 픽셀 면적 기반
        # 고도, 안 보이면 EKF 기반 고도로 "틱마다 소스를 바꿔가며" 썼는데,
        # 이 두 소스가 서로 다른 기준(레�런스)이라 값이 어긋나 있었다.
        # 그 결과 "마커 보이면 하강, 안 보이면 상승"하는 핑퐁(진동)이
        # 발생했다. 게다가 EKF2는 camera_line_scanning.py가 보내는
        # 아루코 기반 고도를 이미 fusion에 반영하고 있어서, 굳이 여기서
        # 또 따로 픽셀 기반 고도를 중복 계산할 필요도 없었다. mode11과
        # 동일하게 EKF 기반 하나로 통일한다.
        current_height = self.ground_z - pos[2]

        if self.mode1_prev_height is not None:
            jump = abs(current_height - self.mode1_prev_height)
            if jump > MODE11_JUMP_WARN_THRESHOLD_M:
                self.get_logger().warn(
                    f'[mode1] 고도 점프 감지! {self.mode1_prev_height:.2f}m -> '
                    f'{current_height:.2f}m (Δ{jump:.2f}m/tick) - '
                    f'line-scanning VIO 추정치가 불안정할 수 있음')
        self.mode1_prev_height = current_height

        if not self.mode1_reached_target:
            if current_height < AUTO_TAKEOFF_HEIGHT - MODE11_HEIGHT_TOLERANCE:
                self.mode1_z_setpoint -= MODE11_CLIMB_STEP
                if self.counter % 10 == 0:
                    self.get_logger().info(
                        f'[mode1] 상승 중 (높이={current_height:.2f}m / '
                        f'목표={AUTO_TAKEOFF_HEIGHT}m)')
            else:
                self.mode1_reached_target = True
                self.get_logger().info(
                    f'[mode1] 목표 고도 도달 (높이={current_height:.2f}m) - '
                    f'이후 계속 호버링하며 안정성만 관찰 (mode3 전환 없음)')
        else:
            # 추가된 부분(핵심): 목표 도달 후에도 고도가 안전밴드
            # (1.5~2.5m)를 벗어나면 다시 목표 고도(2.0m)로 재보정한다.
            # 기존엔 한 번 도달하면 z_setpoint를 영원히 고정해버려서,
            # 그 뒤 무슨 이유로든(부정확한 게인, 드리프트 등) 고도가
            # 틀어져도 전혀 교정을 안 하고 있었다.
            if not self.mode1_correcting:
                if (current_height < MODE1_HEIGHT_RECOVER_LOW
                        or current_height > MODE1_HEIGHT_RECOVER_HIGH):
                    self.mode1_correcting = True
                    self.get_logger().warn(
                        f'[mode1] 고도 이탈 감지(높이={current_height:.2f}m, '
                        f'안전밴드 {MODE1_HEIGHT_RECOVER_LOW}~'
                        f'{MODE1_HEIGHT_RECOVER_HIGH}m 벗어남) - '
                        f'{AUTO_TAKEOFF_HEIGHT}m로 재보정 시작')

            if self.mode1_correcting:
                # 수정된 부분(핵심): 재보정 구간에서는 EKF2 fused pos[2]
                # 대신, 마커가 보이면 픽셀 기반 고도(카메라가 직접 보는
                # 값)를 우선으로 쓴다. 재보정은 "고도가 뭔가 잘못됐다"고
                # 판단해서 들어오는 구간이라, 바로 그 EKF 추정치 자체를
                # 못 믿는 상황일 수 있다 - 그럴 때는 카메라로 직접 잰
                # 값이 더 신뢰할 만하다. 마커가 안 보이는 틱에는 EKF
                # 기반값으로 폴백(재보정 중에도 계속 판단은 해야 하므로).
                correction_height = pixel_height if pixel_height is not None else current_height
                height_source = 'pixel' if pixel_height is not None else 'ekf'

                if correction_height < AUTO_TAKEOFF_HEIGHT - MODE11_HEIGHT_TOLERANCE:
                    self.mode1_z_setpoint -= MODE11_CLIMB_STEP
                elif correction_height > AUTO_TAKEOFF_HEIGHT + MODE11_HEIGHT_TOLERANCE:
                    self.mode1_z_setpoint += MODE11_CLIMB_STEP
                else:
                    self.mode1_correcting = False
                    self.get_logger().info(
                        f'[mode1] 고도 재보정 완료 (높이={correction_height:.2f}m[{height_source}])')

                if self.counter % 10 == 0:
                    self.get_logger().info(
                        f'[mode1] 고도 재보정 중 - 현재 높이='
                        f'{correction_height:.2f}m[{height_source}] '
                        f'(목표={AUTO_TAKEOFF_HEIGHT}m)')
            else:
                if self.counter % 10 == 0:
                    self.get_logger().info(
                        f'[mode1] 호버링 중 - 높이={current_height:.2f}m '
                        f'(목표={AUTO_TAKEOFF_HEIGHT}m, 오차={current_height - AUTO_TAKEOFF_HEIGHT:+.3f}m)')

        self.mode1_z_setpoint = clamp_z_setpoint_to_safety(
            self.ground_z, self.mode1_z_setpoint, MODE1_BLIND_MAX_HEIGHT)

        if aruco_detected_now and not self.mode1_aruco_first_detected:
            self.mode1_aruco_first_detected = True

        if (self.mode1_aruco_first_detected and not self._mode1_xy_p_released
                and self._mode1_xy_p_backup is not None):
            self.set_px4_param('MPC_XY_P', MODE1_XY_P_TARGET)
            self.get_logger().info(
                f'[param] mode1 아루코 마커 최초 검출 - MPC_XY_P: '
                f'0 -> {MODE1_XY_P_TARGET}(고정 목표값) 복원')
            self._mode1_xy_p_released = True

        # 추가된 부분: z게인도 xy와 동일하게, 마커 검출 시 고정값으로 복원
        if (self.mode1_aruco_first_detected and not self._mode1_z_p_released
                and self._mode1_z_p_backup is not None):
            self.set_px4_param('MPC_Z_P', MODE1_Z_P_TARGET)
            self.get_logger().info(
                f'[param] mode1 아루코 마커 최초 검출 - MPC_Z_P: '
                f'0 -> {MODE1_Z_P_TARGET}(고정 목표값) 복원')
            self._mode1_z_p_released = True

        # 추가된 부분: xy 속도루프 I게인도 마커 검출 시 값 변경
        if (self.mode1_aruco_first_detected and not self._mode1_xy_vel_i_released
                and self._mode1_xy_vel_i_backup is not None):
            self.set_px4_param('MPC_XY_VEL_I_ACC', MODE1_XY_VEL_I_TARGET)
            self.get_logger().info(
                f'[param] mode1 아루코 마커 최초 검출 - MPC_XY_VEL_I_ACC: '
                f'{self._mode1_xy_vel_i_backup} -> {MODE1_XY_VEL_I_TARGET} 변경')
            self._mode1_xy_vel_i_released = True

        # 추가된 부분: xy 속도루프 D게인도 마커 검출 시 값 변경
        if (self.mode1_aruco_first_detected and not self._mode1_xy_vel_d_released
                and self._mode1_xy_vel_d_backup is not None):
            self.set_px4_param('MPC_XY_VEL_D_ACC', MODE1_XY_VEL_D_TARGET)
            self.get_logger().info(
                f'[param] mode1 아루코 마커 최초 검출 - MPC_XY_VEL_D_ACC: '
                f'{self._mode1_xy_vel_d_backup} -> {MODE1_XY_VEL_D_TARGET} 변경')
            self._mode1_xy_vel_d_released = True

        # 추가된 부분: z 속도루프 I게인도 마커 검출 시 값 변경
        if (self.mode1_aruco_first_detected and not self._mode1_z_vel_i_released
                and self._mode1_z_vel_i_backup is not None):
            self.set_px4_param('MPC_Z_VEL_I_ACC', MODE1_Z_VEL_I_TARGET)
            self.get_logger().info(
                f'[param] mode1 아루코 마커 최초 검출 - MPC_Z_VEL_I_ACC: '
                f'{self._mode1_z_vel_i_backup} -> {MODE1_Z_VEL_I_TARGET} 변경')
            self._mode1_z_vel_i_released = True

        # 추가된 부분: z 속도루프 D게인도 마커 검출 시 값 변경
        if (self.mode1_aruco_first_detected and not self._mode1_z_vel_d_released
                and self._mode1_z_vel_d_backup is not None):
            self.set_px4_param('MPC_Z_VEL_D_ACC', MODE1_Z_VEL_D_TARGET)
            self.get_logger().info(
                f'[param] mode1 아루코 마커 최초 검출 - MPC_Z_VEL_D_ACC: '
                f'{self._mode1_z_vel_d_backup} -> {MODE1_Z_VEL_D_TARGET} 변경')
            self._mode1_z_vel_d_released = True

        # 수정된 부분(핵심): 0(잠김)/1(풀림)로 다시 단순하게 바꿈 - 확인하기
        # 편하도록. mode1은 이 값을 실제 위치 보정에 곱하는 곳이 없다(=z처럼
        # 고정 setpoint + PX4/EKF에 맡기는 구조라서) - 순수히 "지금
        # MPC_XY_P가 잠겨있는지/풀렸는지"를 보여주는 모니터링용 값이다.
        gain_msg = Float32()
        gain_msg.data = 10.0 if self.mode1_aruco_first_detected else 0.0
        self.mode1_xy_gain_pub.publish(gain_msg)

        if self.counter % 10 == 0:
            xy_error_str = f'{xy_error_m:.3f}m' if xy_error_m is not None else 'N/A'
            self.get_logger().info(
                f'[mode1] aruco_detected={aruco_detected_now} '
                f'(first_detected={self.mode1_aruco_first_detected}, '
                f'MPC_XY_P released={self._mode1_xy_p_released}) '
                f'xy_error={xy_error_str} aligned(<={MODE1_XY_ALIGN_TOLERANCE_M}m)='
                f'{self.mode1_xy_aligned} '
                f'hold=({self.mode1_hold_x:.2f}, {self.mode1_hold_y:.2f})')

        self.publish_setpoint(
            [self.mode1_hold_x, self.mode1_hold_y, self.mode1_z_setpoint,
             MODE1_HOLD_YAW_NED])
        self.counter += 1

    def mode10_step(self):
        pos = self.get_position_from_odometry()
        if pos is None:
            return

        if self.ground_z is None:
            self.ground_z = pos[2]
            self.get_logger().info(f'[mode10] 지면 NED z 기록: {self.ground_z:.3f}m')

        if self.mode10_hold_x is None:
            self.mode10_hold_x = pos[0]
            self.mode10_hold_y = pos[1]
            self.mode10_z_setpoint = pos[2]

        hold_wp = [self.mode10_hold_x, self.mode10_hold_y,
                   self.mode10_z_setpoint, MODE1_HOLD_YAW_NED]

        if not self.ensure_armed_and_offboard(hold_wp):
            return

        current_height = self.ground_z - self.mode10_z_setpoint

        if current_height < AUTO_TAKEOFF_HEIGHT - MODE10_HEIGHT_TOLERANCE:
            self.mode10_z_setpoint -= MODE1_BLIND_CLIMB_STEP
            if self.counter % 10 == 0:
                self.get_logger().info(
                    f'[mode10] 블라인드 상승 중 (높이={current_height:.2f}m / '
                    f'목표={AUTO_TAKEOFF_HEIGHT}m)')
        else:
            self.get_logger().info(
                f'[mode10] 목표 고도 도달 (높이={current_height:.2f}m) -> mode3 자동 전환')
            self._activate_mode3()
            return

        self.mode10_z_setpoint = clamp_z_setpoint_to_safety(
            self.ground_z, self.mode10_z_setpoint, MODE1_BLIND_MAX_HEIGHT)

        self.publish_setpoint(
            [self.mode10_hold_x, self.mode10_hold_y, self.mode10_z_setpoint,
             MODE1_HOLD_YAW_NED])
        self.counter += 1

    def mode11_step(self):
        pos = self.get_position_from_odometry()
        if pos is None:
            return

        if self.ground_z is None:
            self.ground_z = pos[2]
            self.get_logger().info(f'[mode11] 지면 NED z 기록: {self.ground_z:.3f}m')

        if self.mode11_hold_x is None:
            self.mode11_hold_x = pos[0]
            self.mode11_hold_y = pos[1]
            self.mode11_z_setpoint = pos[2]

        hold_wp = [self.mode11_hold_x, self.mode11_hold_y,
                   self.mode11_z_setpoint, MODE1_HOLD_YAW_NED]

        if not self.ensure_armed_and_offboard(hold_wp):
            return

        current_height = self.ground_z - pos[2]

        if self.mode11_prev_height is not None:
            jump = abs(current_height - self.mode11_prev_height)
            if jump > MODE11_JUMP_WARN_THRESHOLD_M:
                self.get_logger().warn(
                    f'[mode11] 고도 점프 감지! {self.mode11_prev_height:.2f}m -> '
                    f'{current_height:.2f}m (Δ{jump:.2f}m/tick) - '
                    f'line-scanning VIO 추정치가 불안정할 수 있음')
        self.mode11_prev_height = current_height

        if not self.mode11_reached_target:
            if current_height < AUTO_TAKEOFF_HEIGHT - MODE11_HEIGHT_TOLERANCE:
                self.mode11_z_setpoint -= MODE11_CLIMB_STEP
                if self.counter % 10 == 0:
                    self.get_logger().info(
                        f'[mode11] 상승 중 (높이={current_height:.2f}m / '
                        f'목표={AUTO_TAKEOFF_HEIGHT}m)')
            else:
                self.mode11_reached_target = True
                self.get_logger().info(
                    f'[mode11] 목표 고도 도달 (높이={current_height:.2f}m) - '
                    f'이후 계속 호버링하며 안정성만 관찰 (mode3 전환 없음)')
        else:
            if self.counter % 10 == 0:
                self.get_logger().info(
                    f'[mode11] 호버링 중 - 높이={current_height:.2f}m '
                    f'(목표={AUTO_TAKEOFF_HEIGHT}m, 오차={current_height - AUTO_TAKEOFF_HEIGHT:+.3f}m)')

        self.mode11_z_setpoint = clamp_z_setpoint_to_safety(
            self.ground_z, self.mode11_z_setpoint, MODE1_BLIND_MAX_HEIGHT)

        xy_gain = (MODE11_XY_GAIN_RELEASED if self.line_first_detected
                   else MODE11_XY_GAIN_LOCKED)

        if (self.line_first_detected and not self._mode11_xy_p_released
                and self._mode11_xy_p_backup is not None):
            self.set_px4_param('MPC_XY_P', self._mode11_xy_p_backup)
            self.get_logger().info(
                f'[param] mode11 라인 최초 인식 - MPC_XY_P: '
                f'0 -> {self._mode11_xy_p_backup}(원래값) 복원')
            self._mode11_xy_p_released = True

        gain_msg = Float32()
        gain_msg.data = float(xy_gain)
        self.mode11_xy_gain_pub.publish(gain_msg)

        lateral_dy = self.centering.last_vision_dy
        xy_correction = float(np.clip(
            lateral_dy * xy_gain, -MODE1_XY_MAX_STEP, MODE1_XY_MAX_STEP))
        corrected_y = self.mode11_hold_y + xy_correction

        if self.counter % 10 == 0:
            self.get_logger().info(
                f'[mode11] xy_gain={xy_gain:.8f} '
                f'(line_first_detected={self.line_first_detected}) '
                f'lateral_dy={lateral_dy:.4f} correction={xy_correction:+.4f}')

        self.publish_setpoint(
            [self.mode11_hold_x, corrected_y, self.mode11_z_setpoint,
             MODE1_HOLD_YAW_NED])
        self.counter += 1

    def mode12_step(self):
        pos = self.get_position_from_odometry()
        if pos is None:
            return

        if self.ground_z is None:
            self.ground_z = pos[2]
            self.get_logger().info(f'[mode12] 지면 NED z 기록: {self.ground_z:.3f}m')

        if self.mode12_hold_x is None:
            self.mode12_hold_x = pos[0]
            self.mode12_hold_y = pos[1]
            self.mode12_z_setpoint = pos[2]

        hold_wp = [self.mode12_hold_x, self.mode12_hold_y,
                   self.mode12_z_setpoint, MODE1_HOLD_YAW_NED]

        if not self.ensure_armed_and_offboard(hold_wp):
            return

        current_height = self.ground_z - pos[2]

        if self.mode12_prev_height is not None:
            jump = abs(current_height - self.mode12_prev_height)
            if jump > MODE11_JUMP_WARN_THRESHOLD_M:
                self.get_logger().warn(
                    f'[mode12] 고도 점프 감지! '
                    f'{self.mode12_prev_height:.2f}m -> {current_height:.2f}m '
                    f'(Δ{jump:.2f}m/tick) - vision 미사용 상태이므로 '
                    f'baro/IMU 쪽 이상일 가능성')
        self.mode12_prev_height = current_height

        if not self.mode12_reached_target:
            if current_height < AUTO_TAKEOFF_HEIGHT - MODE12_HEIGHT_TOLERANCE:
                self.mode12_z_setpoint -= MODE12_BLIND_CLIMB_STEP
                if self.counter % 10 == 0:
                    self.get_logger().info(
                        f'[mode12] 상승 중 (높이={current_height:.2f}m / '
                        f'{AUTO_TAKEOFF_HEIGHT}m, EKF2 baro 기준, vision 미사용)')
            else:
                self.mode12_reached_target = True
                self.get_logger().info(
                    f'[mode12] 목표 고도 도달 (높이={current_height:.2f}m) - '
                    f'이후 계속 호버링 (vision 계속 미사용)')
        else:
            if self.counter % 10 == 0:
                self.get_logger().info(
                    f'[mode12] 호버링 중 - 높이={current_height:.2f}m '
                    f'(오차={current_height - AUTO_TAKEOFF_HEIGHT:+.3f}m, '
                    f'EKF2 baro 기준)')

        self.mode12_z_setpoint = clamp_z_setpoint_to_safety(
            self.ground_z, self.mode12_z_setpoint, MODE1_BLIND_MAX_HEIGHT)

        self.publish_setpoint(
            [self.mode12_hold_x, self.mode12_hold_y, self.mode12_z_setpoint,
             MODE1_HOLD_YAW_NED])
        self.counter += 1

    def mode2_step(self):
        """
        mode2: 버티포트 -> 격자 시작점(0,0)까지, 비전이 안 이어져 있는
        구간을 통과하는 상태머신.

        blind:
            일단 멀리 앞(+x)의 가상 목표점을 향해 그냥 전진.
            수평선(is_vertical=False)이 처음 보이면 align_h로 전환.

        align_h:
            계속 전진하면서, self.centering.last_vision_dy(라인 기준 좌우
            오차)를 y setpoint에 더해서 좌우 정렬(=롤+ 보정).
            수평선이 MODE2_PASS_STREAK_REQUIRED틱 연속으로 안 보이면
            "지나쳤다"고 보고 approach_v로 전환.

        approach_v:
            계속 전진하면서 수직선(is_vertical=True)을 기다림.
            보이는 순간 search_grid로 전환(급정지하지 않음).

        search_grid:
            피치-를 매 틱 조금씩 적용(전방 목표를 서서히 줄임)하면서,
            실제 격자점(교차 패턴)을 찾을 때까지 계속 수색한다.
            찾으면(또는 감속 램프가 다 끝나면) 그 자리에서 hover로 확정.

        hover:
            grid_centering + 아루코 offset으로 (0,0) 위치를 미세보정.
            MODE2_FINE_CORRECT_MAX_TICKS 동안 보정하고 나면 그 자리에
            고정(mode2_stopped=True).
        """
        pos = self.get_position_from_odometry()
        if pos is None:
            return

        if self.mode2_hold_x is None:
            # 최초 1회: 아주 멀리 앞의 가상 목표점을 잡아둔다. 이 좌표에
            # "도착"하는 걸로 판단하는 게 아니라, 그냥 "계속 전진하라"는
            # 방향 지시일 뿐 - 실제 도착 판정은 비전(수평선/수직선)으로 한다.
            self.mode2_hold_x = pos[0] + MODE2_FORWARD_DISTANCE_M
            self.mode2_hold_y = pos[1]
            if self.mode1_z_setpoint is not None:
                self.mode2_z_setpoint = self.mode1_z_setpoint
                self.get_logger().info(
                    f'[mode2] z를 mode1 고도로 고정: {self.mode2_z_setpoint:.3f}m')
            else:
                self.mode2_z_setpoint = pos[2]
                self.get_logger().warn(
                    '[mode2] mode1_z_setpoint가 없음 - 현재 EKF 고도로 폴백')
            self.get_logger().info(
                f'[mode2] 전진 방향 목표 설정: x={self.mode2_hold_x:.2f} '
                f'(현재 x={pos[0]:.2f} + {MODE2_FORWARD_DISTANCE_M:.2f}m), '
                f'z={self.mode2_z_setpoint:.2f}')

        hold_wp = [
            self.mode2_hold_x,
            self.mode2_hold_y,
            self.mode2_z_setpoint,
            float('nan')
        ]

        if not self.ensure_armed_and_offboard(hold_wp):
            return

        rclpy.spin_once(self.cam, timeout_sec=0.0)
        frame = self.cam.read()

        stable_pattern = 'unknown'
        line_detected = False
        is_vertical = None
        mask = None
        pattern_cell_dy = 0
        pattern_cell_dx = 0

        if frame is not None:
            (_, data, pattern_name, live_pattern, live_dist, live_grid,
             _img, _yaw, is_vertical, mask, pattern_cell_dy,
             pattern_cell_dx) = process_frame(frame)
            stable_pattern = self.mode2_pattern_smoother.update(live_pattern)

            line_values = data[:6] if data is not None and len(data) >= 6 else []
            line_detected = any(
                value is not None and float(value) > 0.0
                for value in line_values
            )

        horizontal_now = line_detected and is_vertical is False
        vertical_now = line_detected and is_vertical is True

        # ---- 상태 전이 + 그때그때 보정 ----
        if self.mode2_phase == 'blind':
            if horizontal_now:
                self.mode2_phase = 'align_h'
                self.mode2_pass_streak = 0
                self.get_logger().info(
                    '[mode2] 수평선 첫 감지 - 좌우 정렬 시작(align_h)')

        elif self.mode2_phase == 'align_h':
            # 롤+ 보정: 진행방향(x)은 그대로 두고, 좌우(y)만 라인 기준
            # 오차(last_vision_dy)만큼 계속 보정한다.
            lateral_dy = self.centering.last_vision_dy
            self.mode2_hold_y = pos[1] + lateral_dy

            if horizontal_now:
                self.mode2_pass_streak = 0
            else:
                self.mode2_pass_streak += 1

            if self.mode2_pass_streak >= MODE2_PASS_STREAK_REQUIRED:
                self.mode2_phase = 'approach_v'
                self.get_logger().info(
                    '[mode2] 수평선 지나침 - 수직선 탐색 시작(approach_v)')

        elif self.mode2_phase == 'approach_v':
            if vertical_now:
                # 수정된 부분(핵심): 수직선이 "보이기 시작한" 순간 바로
                # (0,0) 도착으로 간주해서 얼리지 않는다 - 수직선은 교차점
                # 훨씬 전부터도 보일 수 있어서, 그 순간 급정지하면 실제
                # 교차점보다 멀리서(또는 관성 때문에 애매한 곳에서) 서게
                # 된다. 대신 search_grid로 넘어가서, 점진적으로 감속
                # (피치-)하면서 실제 격자점(교차 패턴)을 찾을 때까지
                # 계속 수색한다.
                self.mode2_phase = 'search_grid'
                self.mode2_current_pitch_deg = MODE2_SEARCH_INITIAL_PITCH_DEG
                self.get_logger().info(
                    f'[mode2] 수직선 첫 감지 - 격자점 수색 시작(search_grid), '
                    f'피치 {MODE2_SEARCH_INITIAL_PITCH_DEG:.0f}도부터 점진 감속')

        elif self.mode2_phase == 'search_grid':
            # 피치-: 매 틱 조금씩 감속. mode2_current_pitch_deg가
            # 0으로 줄어들수록 전방 목표(lookahead)도 같이 줄어들어서,
            # 관성으로 인한 급정지 충격 없이 서서히 멈추게 된다.
            self.mode2_current_pitch_deg = max(
                0.0,
                self.mode2_current_pitch_deg - MODE2_SEARCH_PITCH_STEP_DEG
            )
            decel_ratio = self.mode2_current_pitch_deg / MODE2_SEARCH_INITIAL_PITCH_DEG
            lookahead_m = MODE2_SEARCH_LOOKAHEAD_M * decel_ratio
            self.mode2_hold_x = pos[0] + lookahead_m
            self.mode2_hold_y = pos[1]

            # 실제 격자점(교차 패턴)을 찾았는지 확인 - 단순히 수직선이
            # 보이는 것과 달리, cross/T/corner처럼 진짜 "점"에 해당하는
            # 패턴이어야 한다(line_V/H는 여전히 그냥 직선 구간이므로 제외).
            grid_point_found = stable_pattern in (
                'cross', 'T_up', 'T_down', 'T_left', 'T_right',
                'corner_TL', 'corner_TR', 'corner_BL', 'corner_BR'
            )

            decel_finished = self.mode2_current_pitch_deg <= 0.0

            if grid_point_found or decel_finished:
                # 격자점을 찾았거나, 더 감속할 여지가 없으면(감속 램프
                # 완주) 그 자리에서 확정 - 피치- 작업의 최종 정지.
                self.mode2_hold_x = pos[0]
                self.mode2_hold_y = pos[1]
                self.mode2_phase = 'hover'
                self.mode2_fine_correct_ticks = 0

                # 추가된 부분(핵심): 격자점을 인식해서 정밀 정렬(hover)로
                # 들어가는 순간, XY 게인을 mode1(정밀 정렬용)과 동일한
                # "값"으로 바꾼다 - mode1 코드/상수 자체는 안 건드리고,
                # mode1이 쓰는 목표값(MODE1_XY_P_TARGET 등)을 그대로
                # 읽어서 mode2의 PX4 파라미터에 적용하는 것뿐이다.
                # mode2 진입 시 백업해둔 원래값(self._mode2_xy_p_backup
                # 등)은 그대로 두고 값만 바꾸는 거라 - mode2를 완전히
                # 벗어날 때 그 백업값으로 복원되는 기존 로직에는 영향
                # 없다.
                self.set_px4_param('MPC_XY_P', MODE1_XY_P_TARGET)
                self.set_px4_param('MPC_XY_VEL_I_ACC', MODE1_XY_VEL_I_TARGET)
                self.set_px4_param('MPC_XY_VEL_D_ACC', MODE1_XY_VEL_D_TARGET)

                self.get_logger().info(
                    f'[mode2] 호버링 전환 (격자점 발견={grid_point_found}, '
                    f'감속 완주={decel_finished}) '
                    f'(x={pos[0]:.2f}, y={pos[1]:.2f}), '
                    f'XY 게인을 mode1과 동일하게 전환 '
                    f'(P={MODE1_XY_P_TARGET}, I={MODE1_XY_VEL_I_TARGET}, '
                    f'D={MODE1_XY_VEL_D_TARGET})')

        elif self.mode2_phase == 'hover':
            # 수정된 부분(핵심): grid_centering/아루코 계산을
            # MODE2_GRID_COMPUTE_INTERVAL 틱마다 한 번만 돌린다.
            #
            # 주의: 계산을 건너뛴 틱에도 "현재 위치 - 낡은 offset"으로
            # hold_x/y를 매번 재계산하면 안 된다 - 그러면 드론이 이미
            # 목표에 가까워졌는데도 낡은 offset을 또 빼버려서 목표점이
            # 드론을 계속 따라 밀려나고(수렴 안 함/오버슈트) 결국 드론이
            # 밀려버린다. 그래서 계산하는 틱에서만 hold_x/y를 "한 번"
            # 확정하고, 나머지 틱은 그 확정된 좌표를 그대로 재전송만 한다
            # (PX4가 알아서 그 고정된 점으로 날아감).
            #
            # 수정된 부분(확인 필요): 이미지 dy->NED x(전후), dx->NED y(좌우)
            # 축 매핑은 vio_publisher와 같은 카메라 기준으로 재사용했지만,
            # 부호(MODE2_FORWARD_OFFSET_SIGN/MODE2_LATERAL_OFFSET_SIGN)는
            # 시뮬레이션으로 실제 이동 방향 보고 확인 필요.
            corrected = False
            should_compute = (
                self.mode2_fine_correct_ticks % MODE2_GRID_COMPUTE_INTERVAL == 0)

            if should_compute:
                if mask is not None:
                    g_found, _gcx, _gcy, gdx_m, gdy_m, _gkind = \
                        self.mode2_grid_centering.quick_update(
                            mask, frame.shape, stable_pattern,
                            cell_dy=pattern_cell_dy,
                            cell_dx=pattern_cell_dx,
                            line_width_m=0.10)
                    if g_found:
                        self.mode2_hold_x = (
                            pos[0] - MODE2_FORWARD_OFFSET_SIGN * gdy_m)
                        self.mode2_hold_y = (
                            pos[1] + MODE2_LATERAL_OFFSET_SIGN * gdx_m)
                        corrected = True

                if frame is not None:
                    ids, area, corners = detect_aruco(frame)
                    if ids is not None and area > 0 and len(corners) > 0:
                        offset_info = compute_center_offset_m(frame.shape, corners[0])
                        self.mode2_hold_x = (
                            pos[0] - MODE2_FORWARD_OFFSET_SIGN
                            * offset_info['y_offset_m'])
                        self.mode2_hold_y = (
                            pos[1] + MODE2_LATERAL_OFFSET_SIGN
                            * offset_info['x_offset_m'])
                        corrected = True
            # else: 계산 스킵 - mode2_hold_x/y를 절대 건드리지 않는다.
            # 직전에 확정된 좌표를 그대로 유지한 채 아래에서 재전송된다.

            self.mode2_fine_correct_ticks += 1
            if self.mode2_fine_correct_ticks >= MODE2_FINE_CORRECT_MAX_TICKS:
                self.mode2_stopped = True
                self.get_logger().info(
                    f'[mode2] 최종 위치 보정 완료(마지막 계산 반영={corrected}) - '
                    f'(0,0) 호버링 고정 (x={self.mode2_hold_x:.2f}, '
                    f'y={self.mode2_hold_y:.2f})')

        self.publish_setpoint([
            self.mode2_hold_x,
            self.mode2_hold_y,
            self.mode2_z_setpoint,
            float('nan')
        ])

        if self.counter % 10 == 0:
            self.get_logger().info(
                f'[mode2] phase={self.mode2_phase} '
                f'is_vertical={is_vertical} line_detected={line_detected} '
                f'pass_streak={self.mode2_pass_streak} '
                f'stopped={self.mode2_stopped} '
                f'target=({self.mode2_hold_x:.2f}, {self.mode2_hold_y:.2f}, '
                f'{self.mode2_z_setpoint:.2f}) '
                f'cur=({pos[0]:.2f}, {pos[1]:.2f}, {pos[2]:.2f})')

        self.counter += 1

    def _mode3_init_grid_log(self, csv_path):
        self.mode3_grid_log_csv = csv_path
        try:
            with open(csv_path, 'w', newline='') as f:
                writer = csv.writer(f)
                writer.writerow(['index', 'x', 'y', 'mode', 'is_marker', 'pattern', 'tick'])
        except Exception as e:
            self.get_logger().error(f'[mode3] 격자점 로그 CSV 초기화 실패: {e}')

    def _mode3_log_grid_visit(self, index, wp, pattern):
        try:
            with open(self.mode3_grid_log_csv, 'a', newline='') as f:
                writer = csv.writer(f)
                writer.writerow([index, wp['x'], wp['y'], wp['mode'],
                                  wp['is_marker'], pattern, self.counter])
        except Exception as e:
            self.get_logger().error(f'[mode3] 격자점 로그 기록 실패: {e}')

    def build_mode3_waypoints(self, path_result_csv, way_point_csv):
        full_path = load_table_from_csv(path_result_csv)
        if not full_path:
            raise ValueError(f'{path_result_csv}에 격자점이 없습니다.')

        marker_coords = load_table_from_csv(way_point_csv)
        marker_set = {(round(x, 3), round(y, 3)) for x, y in marker_coords}

        waypoints = []
        for i, (gx, gy) in enumerate(full_path):
            ned_x = gy
            ned_y = gx

            if i < len(full_path) - 1:
                nx, ny = full_path[i + 1]
                dx_abs, dy_abs = abs(nx - gx), abs(ny - gy)
                mode = 'V' if dy_abs >= dx_abs else 'H'
            elif i > 0:
                px, py = full_path[i - 1]
                pnx, pny = gx - px, gy - py
                mode = 'V' if abs(pny) >= abs(pnx) else 'H'
            else:
                mode = 'V'

            yaw_ned = wrap_pi(math.pi / 2.0)

            is_marker = (round(gx, 3), round(gy, 3)) in marker_set

            waypoints.append({
                'x': float(ned_x),
                'y': float(ned_y),
                'yaw': yaw_ned,
                'mode': mode,
                'is_marker': is_marker,
            })

        self.get_logger().info(
            f'[mode3] path_result.csv 로드 완료: 격자점 {len(waypoints)}개 '
            f'(마커 {sum(w["is_marker"] for w in waypoints)}개)')
        return waypoints

    def _mode3_advance(self):
        if self.mode3_index >= len(self.mode3_waypoints) - 1:
            self.get_logger().info('[mode3] 미션 완료 - 마지막 격자점 유지')
            last = self.mode3_waypoints[-1]
            self.mode3_hold_wp = {
                'x': last['x'],
                'y': last['y'],
                'yaw': last['yaw'],
                'mode': last['mode'],
                'is_marker': False,
            }
            self.mode3_mission_complete = True
        else:
            self.mode3_index += 1
        self.mode3_at_intersection = False

    def mode3_step(self):
        if not self.mode3_waypoints:
            self.get_logger().error('[mode3] waypoints가 계산되지 않았습니다.')
            return

        if self.mode3_mission_complete:
            wp = self.mode3_hold_wp
        else:
            wp = self.mode3_waypoints[self.mode3_index]

        mission_z = self.ground_z - AUTO_TAKEOFF_HEIGHT \
            if self.ground_z is not None else None
        if mission_z is None:
            pos = self.get_position_from_odometry()
            mission_z = pos[2] if pos is not None else -AUTO_TAKEOFF_HEIGHT

        hold_wp = [wp['x'], wp['y'], mission_z, wp['yaw']]
        if not self.ensure_armed_and_offboard(hold_wp):
            return

        rclpy.spin_once(self.cam, timeout_sec=0.0)
        frame = self.cam.read()

        stable_pattern = 'unknown'
        if frame is not None:
            edges_color, data, pattern_name, live_pattern, live_dist, live_grid, *_rest = \
                process_frame(frame)
            stable_pattern = self.mode3_pattern_smoother.update(live_pattern)

            write_current_waypoint(
                index=self.mode3_index, total=len(self.mode3_waypoints),
                x=wp['x'], y=wp['y'], is_marker=wp['is_marker'], pattern=stable_pattern)

        if self.mode3_hovering and wp['is_marker']:
            current_area = None
            ids = None
            offset_info = None
            if frame is not None:
                ids, area, corners = detect_aruco(frame)
                if area > 0:
                    current_area = area
                if ids is not None and len(corners) > 0:
                    offset_info = compute_center_offset(frame.shape, corners[0])

            if current_area is not None and self.target_aruco_area is not None:
                error = current_area - self.target_aruco_area
                if error > MODE1_AREA_TOLERANCE:
                    self.mode3_marker_z_setpoint -= compute_z_step_from_area_error(
                        error, self.target_aruco_area)
                elif error < -MODE1_AREA_TOLERANCE:
                    self.mode3_marker_z_setpoint += compute_z_step_from_area_error(
                        error, self.target_aruco_area)

                if self.counter % 5 == 0:
                    self.get_logger().info(
                        f'[mode3] 마커 보정 중: area={current_area:.0f} '
                        f'target={self.target_aruco_area:.0f} error={error:+.0f} '
                        f'z={self.mode3_marker_z_setpoint:.2f}')
            else:
                error = None
                current_height = self.ground_z - self.mode3_marker_z_setpoint \
                    if self.ground_z is not None else 0.0
                if current_height < MODE1_BLIND_MAX_HEIGHT:
                    self.mode3_marker_z_setpoint -= MODE1_BLIND_CLIMB_STEP
                    if self.counter % 10 == 0:
                        self.get_logger().warn(
                            f'[mode3] 마커 미검출 - 블라인드 상승 중 '
                            f'(높이={current_height:.2f}m, z={self.mode3_marker_z_setpoint:.2f})')
                else:
                    if self.counter % 10 == 0:
                        self.get_logger().warn(
                            f'[mode3] 마커 미검출 - 안전 상한({MODE1_BLIND_MAX_HEIGHT}m) '
                            f'도달, 더 이상 상승하지 않음')

            self.mode3_marker_z_setpoint = clamp_z_setpoint_to_safety(
                self.ground_z, self.mode3_marker_z_setpoint, MODE1_BLIND_MAX_HEIGHT)


            hold_wp = [wp['x'], wp['y'], self.mode3_marker_z_setpoint, wp['yaw']]
            self.publish_setpoint(hold_wp)

            if ids is not None:
                for i in ids:
                    marker_id = int(i[0])
                    if self.mode3_marker_store.add(
                            marker_id, wp['x'], wp['y'], self.mode3_marker_z_setpoint, self.counter):
                        self.mode3_marker_store.save()
                        self.get_logger().info(
                            f'[mode3] 마커 {marker_id} 인식 및 기록 '
                            f'@ x={wp["x"]:.2f} y={wp["y"]:.2f}')

            converged = (error is not None and abs(error) <= MODE1_AREA_TOLERANCE)
            timed_out = (self.counter - self.mode3_marker_correction_start
                         >= MODE3_MARKER_CORRECTION_MAX_TICKS)
            if timed_out and not converged:
                self.get_logger().warn(
                    '[mode3] 마커 보정 타임아웃 - 수렴 못했지만 그냥 출발')

            if not (converged or timed_out):
                self.counter += 1
                return

            self.get_logger().info('[mode3] 마커 보정 완료 - 바로 출발')
            self.mode3_hovering = False
            self._mode3_advance()
            self.counter += 1
            return

        if self.mode3_hovering:
            hold_wp = [wp['x'], wp['y'], mission_z, wp['yaw']]
            self.publish_setpoint(hold_wp)

            if self.counter % 10 == 0:
                self.get_logger().info(
                    f'[mode3] 격자점 호버링 중(pattern={stable_pattern}): '
                    f'{self.counter - self.mode3_hover_timer}/{MODE3_HOVER_TICKS} tick')
            if self.counter - self.mode3_hover_timer < MODE3_HOVER_TICKS:
                self.counter += 1
                return
            self.mode3_hovering = False
            self._mode3_advance()
            self.counter += 1
            return

        lateral_dy = self.centering.last_vision_dy
        if wp['mode'] == 'V':
            corrected_wp = [wp['x'], wp['y'] + lateral_dy, mission_z, wp['yaw']]
        else:
            corrected_wp = [wp['x'] + lateral_dy, wp['y'], mission_z, wp['yaw']]

        arrived = (stable_pattern != 'unknown')

        if arrived:
            if not self.mode3_mission_complete and not self.mode3_at_intersection:
                self.mode3_at_intersection = True
                self.get_logger().info(
                    f'[mode3] 격자점 도착 감지(pattern={stable_pattern}) - '
                    f'{self.mode3_index + 1}/{len(self.mode3_waypoints)} '
                    f'(marker={wp["is_marker"]})')
                self._mode3_log_grid_visit(self.mode3_index, wp, stable_pattern)
                self.mode3_hovering = True
                self.mode3_hover_timer = self.counter
                if wp['is_marker']:
                    self.mode3_marker_z_setpoint = mission_z
                    self.mode3_marker_correction_start = self.counter
        else:
            self.mode3_at_intersection = False

        self.publish_setpoint(corrected_wp)
        self.counter += 1

    def timer_callback(self):
        if self.active_mode is None:
            return

        self.publish_offboard_control_mode()

        if self.active_mode == 'mode1':
            self.mode1_step()
        elif self.active_mode == 'mode2':
            self.mode2_step()
        elif self.active_mode == 'mode3':
            self.mode3_step()
        elif self.active_mode == 'mode10':
            self.mode10_step()
        elif self.active_mode == 'mode11':
            self.mode11_step()
        elif self.active_mode == 'mode12':
            self.mode12_step()


def main(args=None):
    rclpy.init(args=args)
    node = WaypointFollower()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    node.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()
