import cv2
import numpy as np
from collections import Counter, deque

GRID_SIZE = 5
THRESHOLD = 0.1

_BASE_PATTERNS = {
    'cross': np.array([
        [0, 0, 1, 0, 0],
        [0, 0, 1, 0, 0],
        [1, 1, 1, 1, 1],
        [0, 0, 1, 0, 0],
        [0, 0, 1, 0, 0],
    ]),
    'T_up': np.array([
        [0, 0, 0, 0, 0],
        [0, 0, 0, 0, 0],
        [1, 1, 1, 1, 1],
        [0, 0, 1, 0, 0],
        [0, 0, 1, 0, 0],
    ]),
    'T_down': np.array([
        [0, 0, 1, 0, 0],
        [0, 0, 1, 0, 0],
        [1, 1, 1, 1, 1],
        [0, 0, 0, 0, 0],
        [0, 0, 0, 0, 0],
    ]),
    'T_left': np.array([
        [0, 0, 1, 0, 0],
        [0, 0, 1, 0, 0],
        [0, 0, 1, 1, 1],
        [0, 0, 1, 0, 0],
        [0, 0, 1, 0, 0],
    ]),
    'T_right': np.array([
        [0, 0, 1, 0, 0],
        [0, 0, 1, 0, 0],
        [1, 1, 1, 0, 0],
        [0, 0, 1, 0, 0],
        [0, 0, 1, 0, 0],
    ]),
    'corner_TL': np.array([
        [0, 0, 0, 0, 0],
        [0, 0, 0, 0, 0],
        [0, 0, 1, 1, 1],
        [0, 0, 1, 0, 0],
        [0, 0, 1, 0, 0],
    ]),
    'corner_TR': np.array([
        [0, 0, 0, 0, 0],
        [0, 0, 0, 0, 0],
        [1, 1, 1, 0, 0],
        [0, 0, 1, 0, 0],
        [0, 0, 1, 0, 0],
    ]),
    'corner_BL': np.array([
        [0, 0, 1, 0, 0],
        [0, 0, 1, 0, 0],
        [0, 0, 1, 1, 1],
        [0, 0, 0, 0, 0],
        [0, 0, 0, 0, 0],
    ]),
    'corner_BR': np.array([
        [0, 0, 1, 0, 0],
        [0, 0, 1, 0, 0],
        [1, 1, 1, 0, 0],
        [0, 0, 0, 0, 0],
        [0, 0, 0, 0, 0],
    ]),
    'line_V': np.array([
        [0, 0, 1, 0, 0],
        [0, 0, 1, 0, 0],
        [0, 0, 1, 0, 0],
        [0, 0, 1, 0, 0],
        [0, 0, 1, 0, 0],
    ]),
    'line_H': np.array([
        [0, 0, 0, 0, 0],
        [0, 0, 0, 0, 0],
        [1, 1, 1, 1, 1],
        [0, 0, 0, 0, 0],
        [0, 0, 0, 0, 0],
    ]),
}

# паттерны, для которых считаем диагональные сдвиги (не только прямые)
_CORNER_NAMES = {'corner_TL', 'corner_TR', 'corner_BL', 'corner_BR'}


def _shift_pattern(pattern, dy, dx):
    """Сдвигает паттерн на (dy, dx) клеток, обнуляя клетки, 'заехавшие' с обратной стороны."""
    p = np.roll(pattern, dy, axis=0)
    p = np.roll(p, dx, axis=1)
    p = p.copy()
    if dy > 0:
        p[:dy, :] = 0
    elif dy < 0:
        p[dy:, :] = 0
    if dx > 0:
        p[:, :dx] = 0
    elif dx < 0:
        p[:, dx:] = 0
    return p


def generate_shifted_patterns(patterns):
    shifted = {}
    for name, pattern in patterns.items():
        shifted[name] = pattern

        if name in _CORNER_NAMES:
            # для угловых паттернов - все 8 направлений сдвига на 1 клетку
            # (4 прямых + 4 диагональных), т.к. дрон может смещаться в любую сторону
            for dy in (-1, 0, 1):
                for dx in (-1, 0, 1):
                    if dy == 0 and dx == 0:
                        continue
                    key = f'{name}_dy{dy}_dx{dx}'
                    shifted[key] = _shift_pattern(pattern, dy, dx)
        else:
            # для остальных паттернов - как раньше, только 4 прямых сдвига
            p_left = _shift_pattern(pattern, 0, -1)
            shifted[f'{name}_sl'] = p_left
            p_right = _shift_pattern(pattern, 0, 1)
            shifted[f'{name}_sr'] = p_right
            p_up = _shift_pattern(pattern, -1, 0)
            shifted[f'{name}_su'] = p_up
            p_down = _shift_pattern(pattern, 1, 0)
            shifted[f'{name}_sd'] = p_down
    return shifted


PATTERNS = generate_shifted_patterns(_BASE_PATTERNS)


def normalize_pattern(name):
    for suffix in ('_sl', '_sr', '_su', '_sd'):
        if name.endswith(suffix):
            return name[: -len(suffix)]
    # диагональные суффиксы вида _dy-1_dx1, _dy1_dx-1 и т.п.
    idx = name.find('_dy')
    if idx != -1:
        return name[:idx]
    return name


def parse_pattern_shift(raw_name):
    """
    generate_shifted_patterns()가 만든 raw 매칭 키(예: 'cross_sl',
    'corner_TL_dy1_dx-1')에서 격자 셀 기준 이동량(dy, dx)을 뽑아낸다.
    이동이 없는 기본(중앙) 패턴이면 (0, 0).

    이 값은 "매칭된 모양이 5x5 격자에서 중앙 셀 기준 몇 칸 옮겨진
    버전이었는지"를 알려준다 - 즉 실제 교차점이 화면 중앙에서 대략
    몇 칸 벗어나 있었는지를 빠르게 추정하는 데 쓸 수 있다
    (grid_centering.quick_update의 seed 좌표 계산용).
    """
    if raw_name.endswith('_sl'):
        return 0, -1
    if raw_name.endswith('_sr'):
        return 0, 1
    if raw_name.endswith('_su'):
        return -1, 0
    if raw_name.endswith('_sd'):
        return 1, 0

    idx = raw_name.find('_dy')
    if idx != -1:
        rest = raw_name[idx + 3:]  # "{dy}_dx{dx}" 형태
        dy_str, dx_str = rest.split('_dx')
        return int(dy_str), int(dx_str)

    return 0, 0


def _find_best_pattern(grid, max_distance):
    best_name = 'unknown'
    best_dist = max_distance + 1
    for name, pattern in PATTERNS.items():
        dist = hamming_distance(grid, pattern)
        if dist < best_dist:
            best_dist = dist
            best_name = name
    return best_name, best_dist


def mask_to_grid(mask, grid_size=GRID_SIZE, threshold=THRESHOLD):
    h, w = mask.shape
    cell_h = h // grid_size
    cell_w = w // grid_size
    grid = np.zeros((grid_size, grid_size), dtype=int)
    for row in range(grid_size):
        for col in range(grid_size):
            y1 = row * cell_h
            y2 = y1 + cell_h
            x1 = col * cell_w
            x2 = x1 + cell_w
            cell = mask[y1:y2, x1:x2]
            ratio = cv2.countNonZero(cell) / cell.size
            grid[row, col] = 1 if ratio > threshold else 0
    return grid


def hamming_distance(a, b):
    return int(np.sum(a != b))


def detect_pattern(mask, max_distance=6):
    grid = mask_to_grid(mask)
    best_name, best_dist = _find_best_pattern(grid, max_distance)
    if best_dist > max_distance:
        return 'unknown', best_dist, grid
    return normalize_pattern(best_name), best_dist, grid


def detect_pattern_with_shift(mask, max_distance=6):
    """
    detect_pattern()과 완전히 동일하게 동작하지만, 매칭된 템플릿이
    기준(중앙) 위치에서 몇 칸 이동(shift)된 버전이었는지(cell_dy,
    cell_dx)도 같이 반환한다. 기존 detect_pattern()의 반환 형식(3-tuple)을
    쓰는 다른 호출부를 안 건드리려고 별도 함수로 뺐다.

    반환: name, dist, grid, cell_dy, cell_dx
    """
    grid = mask_to_grid(mask)
    best_name, best_dist = _find_best_pattern(grid, max_distance)
    if best_dist > max_distance:
        return 'unknown', best_dist, grid, 0, 0
    cell_dy, cell_dx = parse_pattern_shift(best_name)
    return normalize_pattern(best_name), best_dist, grid, cell_dy, cell_dx


def draw_grid(edges_color, mask, grid_size=GRID_SIZE, pattern_grid=None):
    h, w = mask.shape
    cell_h = h // grid_size
    cell_w = w // grid_size

    overlay = edges_color.copy()

    # подсветка активных ячеек (если передан grid паттерна)
    if pattern_grid is not None:
        for row in range(grid_size):
            for col in range(grid_size):
                if pattern_grid[row, col] == 1:
                    x1, y1 = col * cell_w, row * cell_h
                    x2, y2 = x1 + cell_w, y1 + cell_h
                    cv2.rectangle(overlay, (x1, y1), (x2, y2), (0, 140, 255), -1)
        cv2.addWeighted(overlay, 0.15, edges_color, 0.85, 0, edges_color)

    mid = grid_size // 2
    for i in range(1, grid_size):
        # центральные линии (там обычно проходит крест) - ярче и толще
        if i == mid or i == mid + (0 if grid_size % 2 else 1):
            color, thick = (0, 220, 220), 2
        else:
            color, thick = (90, 90, 90), 1
        cv2.line(edges_color, (i * cell_w, 0), (i * cell_w, h), color, thick, cv2.LINE_AA)
        cv2.line(edges_color, (0, i * cell_h), (w, i * cell_h), color, thick, cv2.LINE_AA)

    return edges_color


class PatternSmoother:
    def __init__(self, history_size=7):
        self.history = deque(maxlen=history_size)

    def update(self, pattern_name):
        self.history.append(pattern_name)
        if not self.history:
            return 'unknown'
        return Counter(self.history).most_common(1)[0][0]

    def reset(self):
        self.history.clear()


if __name__ == '__main__':
    print(f'총 패턴 수: {len(PATTERNS)}')
    for name in PATTERNS:
        print(name)
